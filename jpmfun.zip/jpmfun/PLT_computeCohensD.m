
% Function to Compute Cohen's D
function d = PLT_computeCohensD(group1, group2)
    mean1 = mean(group1, 1);
    mean2 = mean(group2, 1);
    std1 = std(group1, 0, 1);
    std2 = std(group2, 0, 1);
    
    pooled_std = sqrt(((std1 .^ 2) + (std2 .^ 2)) / 2);
    d = (mean1 - mean2) ./ pooled_std;
end