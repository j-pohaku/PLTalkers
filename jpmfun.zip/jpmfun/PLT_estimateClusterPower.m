% Function for Cluster-Based Power Estimation
function clusterPower = PLT_estimateClusterPower(d, n_perm)
    perm_dist = zeros(n_perm, 1);
    
    for i = 1:n_perm
        perm_labels = randperm(numel(d));
        perm_dist(i) = mean(d(perm_labels));  % Randomized effect
    end
    
    clusterPower = mean(perm_dist > mean(d));
end