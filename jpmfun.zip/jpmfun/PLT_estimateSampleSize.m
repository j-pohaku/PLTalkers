
% Function to Estimate Required Sample Size
function n = PLT_estimateSampleSize(d, power, alpha)
    z_alpha = norminv(1 - alpha/2); % Two-tailed test
    z_beta = norminv(power); % Power level

    
    n = ( (z_alpha + z_beta) ./ d ) .^ 2;



end