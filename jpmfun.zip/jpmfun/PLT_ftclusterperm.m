
%% stats 


close all
clearvars
clc
restoredefaultpath;
addpath(genpath('C:\Users\local.admin\Documents\MATLAB\mTRF-Toolbox-master\'));
addpath 'C:\Users\local.admin\Documents\MATLAB\speechenv_toolbox\';
% addpath 'C:\Users\local.admin\Documents\MATLAB/NoiseTools/'; % http://audition.ens.fr/adc/NoiseTools/
addpath 'C:\Users\local.admin\Documents\MATLAB\eeglab\eeglab2022.1\';
addpath 'C:\Users\local.admin\Documents\MATLAB\fieldtrip-master\fieldtrip-master\';
addpath 'C:\Users\local.admin\Documents\MATLAB\redblue\';
mycolors=redblue(256);
% addpath('/Users/jpohaku/Documents/MATLAB/fieldtrip-master/fieldtrip-master/external/spm2');
homefolder='C:\Users\local.admin\Documents\nonYaleResearch\YALEPLTALKERS\';
dsh=homefolder(end);
cd(homefolder)
addpath(genpath(homefolder))
format long g
subjectfolder=[homefolder 'subjectdata' dsh];
setupfolder=[homefolder 'setupfiles' dsh];
outputfolder=[homefolder 'TRFoutput' dsh];
load([setupfolder 'AVsenBehdata20subs.mat']);subnames=fieldnames(behdtatrinityall);
load([setupfolder 'PLTchanlocs.mat']);
trfchans={chanlocs(:).labels};


load([setupfolder 'GA_4ft_byfreqzp1.mat']);
condnames=fieldnames(GA_4ft);
GA_erf=GA_4ft.AVC;

for c=1:length(condnames)
GA_4ft_smooth.(condnames{c})=GA_4ft.(condnames{c});
for s=1:20
    for ch=1:26
GA_4ft_smooth.(condnames{c}).individual(s,ch,:)=smoothdata(GA_4ft_smooth.(condnames{c}).individual(s,ch,:));
    end
end
end

trfchans_use=trfchans;
trfchans_use([1 2 7 8 17 18 9:16 23 24])=[];

trfchans_use={'Cz','C3','C4'};
% Load FieldTrip
ft_defaults;
% Define neighbors (spatial clustering) - adjust based on your electrode layout
cfg_neighb = [];
cfg_neighb.method = 'template'; % or 'template' for predefined layouts
cfg_neighb.elec = GA_erf.elec; % Use electrode structure from your data
neighbours = ft_prepare_neighbours(cfg_neighb, GA_erf);

% Statistical configuration
cfg = [];
% cfg.spmversion = 'spm8';
cfg.channel = 'all'; % Use all electrodes
%cfg.channel = trfchans_use;
% cfg.latency = [0 0.3]; % Time window in seconds 
 cfg.latency = [0.15 0.220]; % Time window in seconds 
%cfg.latency = [0.03 0.1]; % Time window in seconds 

cfg.method = 'montecarlo'; % Permutation test
cfg.statistic = 'ft_statfun_depsamplesT'; % Paired samples t-test
cfg.correctm = 'cluster'; % Cluster-based correction
cfg.clusteralpha = 0.05; % Threshold for forming clusters
cfg.clusterstatistic = 'maxsum'; % Statistic for cluster evaluation
cfg.minnbchan = 2; % Minimum neighboring channels for a cluster
cfg.neighbours = neighbours; % Defined neighbors
cfg.tail = 0; % Two-tailed test
cfg.clustertail = 0;
cfg.alpha = 0.05; % Significance level
cfg.numrandomization = 1000; % Number of permutations
%cfg.avgovertime = 'yes';

% Design matrix for paired samples
numSubjects = length(subnames);
design = zeros(2, 2*numSubjects);
design(1,:) = [1:numSubjects 1:numSubjects]; % Subject index
design(2,:) = [ones(1,numSubjects) 2*ones(1,numSubjects)]; % Condition labels

cfg.design = design;
cfg.ivar = 2; % Independent variable (condition)
cfg.uvar = 1; % Subject variable
% Run the statistical test
clearvars stat statAVC
statAVC.AVI = ft_timelockstatistics(cfg, GA_4ft.(condnames{1}), GA_4ft.(condnames{2}));
statAVC.ApV = ft_timelockstatistics(cfg, GA_4ft.(condnames{1}), GA_4ft.(condnames{3}));
statAVC.A = ft_timelockstatistics(cfg, GA_4ft.(condnames{1}), GA_4ft.(condnames{4}));


clc;
disp([statAVC.AVI.negclusters(:).prob]);
disp([statAVC.AVI.posclusters(:).prob]);
clc;
disp([statAVC.ApV.negclusters(:).prob]);
disp([statAVC.ApV.posclusters(:).prob]);
clc;
disp([statAVC.A.negclusters(:).prob]);
disp([statAVC.A.posclusters(:).prob]);


clearvars sigstats
sigstats.times=statAVC.ApV.time(sum(statAVC.ApV.negclusterslabelmat==1,1)>0); % 26 x 78
sigstats.chans=statAVC.ApV.label(sum(statAVC.ApV.negclusterslabelmat==1,2)>0);clc;
disp(sigstats);disp(sigstats.chans);

clearvars sigstats
sigstats.times=statAVC.A.time(sum(statAVC.A.negclusterslabelmat==1,1)>0); % 26 x 78
sigstats.chans=statAVC.A.label(sum(statAVC.A.negclusterslabelmat==1,2)>0);clc;
disp(sigstats);disp(sigstats.chans);

% stat = ft_timelockstatistics(cfg, GA_4ft_smooth.(condnames{1}), GA_4ft_smooth.(condnames{4}));
% stat_z = ft_timelockstatistics(cfg, GA_4ft_z.(condnames{1}), GA_4ft_z.(condnames{3}));


clearvars sigstats
sigstats.times=stat.time(sum(stat.negclusterslabelmat==1,1)>0); % 26 x 78
sigstats.chans=stat.label(sum(stat.negclusterslabelmat==1,2)>0);clc;
disp(sigstats);disp(sigstats.chans);

clearvars sigstats
sigstats.times=stat.time(sum(stat.posclusterslabelmat==1,1)>0); % 26 x 78
sigstats.chans=stat.label(sum(stat.posclusterslabelmat==1,2)>0);clc;
disp(sigstats);disp(sigstats.chans);

clearvars sigstats
sigstats.times=stat.time(sum(stat.negclusterslabelmat==2,1)>0); % 26 x 78
sigstats.chans=stat.label(sum(stat.negclusterslabelmat==2,2)>0);
disp(sigstats);

% Plot results (topographical clusters)
close all
cfg = [];
cfg.alpha = 0.05; % Cluster significance threshold
cfg.parameter = 'stat';
cfg.colormap = mycolors;
ft_clusterplot(cfg, stat);


%% plot

% Load EEGLAB if available
eeglab; % Uncomment if using EEGLAB

% Example 3D ERP matrix: conditions x time x channels
% Replace with your actual data
n_conditions = 5;
n_timepoints = 78;
n_channels = 26;

clearvars erp_data erp_data_diff erp_data_smooth
for c=1:length(condnames)
erp_data(c,:,:)= permute(mean(GA_4ft.(condnames{c}).individual,1),[1 3 2]);
erp_data_smooth(c,:,:)= permute(mean(GA_4ft_smooth.(condnames{c}).individual,1),[1 3 2]);

end
for c=1:length(condnames)
erp_data_diff(c,:,:)=erp_data(1,:,:)-erp_data(c,:,:);
end

% Define channel locations (modify based on your EEG system)
timeaxis=GA_4ft.(condnames{c}).time;


plottimes=0:0.05:0.3;
% Select condition, time point
newplots=[];
close all
newplots.AVC=erp_data(1,:,:);
%newplots.ApV=erp_data(3,:,:);
newplots.A=erp_data(4,:,:);
newplots.V=erp_data(5,:,:);
newplots.AVI=erp_data(2,:,:);

% newplots.AVC=erp_data_smooth(1,:,:);
% newplots.ApV=erp_data_smooth(3,:,:);
% newplots.AVI=erp_data_smooth(2,:,:);
% newplots.A=erp_data_smooth(4,:,:);
% newplots.V=erp_data_smooth(5,:,:);
plotnames=fieldnames(newplots);

close all
counter=0;
for c=1:length(plotnames)
    for pt=1:length(plottimes)
        counter=counter+1;
        [~,pidx1]=min(abs(timeaxis-plottimes(pt)));
        time_idx = pidx1;%:pidx2; % Midway in time
        topo_data = squeeze(mean(newplots.(plotnames{c})(1,time_idx, :),2)); % 64 x 1 vector
       % topo_data = squeeze(sum(abs(newplots.(plotnames{c})(1,14:52, :)),2)); % 64 x 1 vector
        % Plot topographic map
        subplot(length(plotnames),length(plottimes),counter)
%         'map'      -> plot colored map only
%                         'contour'  -> plot contour lines only
%                         'both'     -> plot both colored map and contour lines
%                         'fill'     -> plot constant color between contour lines
%                         'blank'  
        % h=topoplot(topo_data, chanlocs,'ColorMap',mycolors, 'maplimits', [-1 2.5],'style','both', 'electrodes', 'on',...
        %    'emarker' ,{'.','k',[],.1} ,'shading', 'interp');
        h=topoplot(topo_data, chanlocs,'ColorMap',mycolors, 'maplimits', [-2 2],'style','both', 'electrodes', 'off',...
            'shading', 'interp');
       hold on
      % h.MarkerSize=1;
        colormap(mycolors);
        colorbar;
       % title([ plotnames{c} ' ' num2str(time_idx)]);
    end
    %title(sprintf('ERP Topography - Condition %d, Time %d ms', condition, time_idx));
end
% set(gcf, 'Position', [196.2,463.4,1014.4,288.0000000000001]);
set(gcf, 'Position', [92.2,69.8,1395.2,798.4000000000001]);

close all
topoplot(topo_data, chanlocs,'ColorMap',mycolors, 'maplimits', [-3 3],'style','blank', 'electrodes', 'off',...
            'shading', 'interp');
 set(gcf, 'Position', [673.8000000000001,438,374.1999999999999,227.8]);

close all
cfg=[];
cfg.channel       = {'Fz','Cz','FC1','FC2'};
cfg.channel       = {'Oz','O1','O2'};

cfg.ylim=[-2 2.5];
cfg.xlim=[-0.05 0.4];
cfg.linewidth=2;
cfg.showlegend    = 'no';
cfg.title=' ';
% Create a new figure

cfg.linecolor=[0.00,0.451,0.7412; 0.84 0.68 0.22;0.635 0.078 0.184;.1 0.5 0.2];
% ft_singleplotER(cfg,GA_4ft.AVC,GA_4ft.ApV); hold on; yline(0); xline(0)
ft_singleplotER(cfg,GA_4ft_smooth.V,GA_4ft_smooth.A,GA_4ft_smooth.AVI,GA_4ft_smooth.AVC); hold on; yline(0); xline(0)
set(gca,'xtick',0:0.1:0.4,'xticklabel',{0:100:400})
set(gca,'ytick',-2:2:2,'yticklabel',{-2:2:2})
xlabel('Time (ms)')
ylabel('TRF β')
% xline(0.14,'Color',[0 0 0],'Linewidth',1,'LineStyle','--')
% xline(0.16,'Color',[0 0 0],'Linewidth',1,'LineStyle','--')
set(gcf, 'Position', [488,317,386.6,265.6]);



%subplot(1,3,1)
cfg.linecolor=[.1 0.5 0.2; 0.5 0.5 0.5];
% ft_singleplotER(cfg,GA_4ft.AVC,GA_4ft.ApV); hold on; yline(0); xline(0)
ft_singleplotER(cfg,GA_4ft_smooth.AVC,GA_4ft_smooth.ApV); hold on; yline(0); xline(0)
set(gca,'xtick',0:0.1:0.4,'xticklabel',{0:100:400})
set(gca,'ytick',-2:2:2,'yticklabel',{-2:2:2})
xlabel('Time (ms)')
ylabel('TRF β')
 xline(0.14,'Color',[0 0 0],'Linewidth',1,'LineStyle','--')
 xline(0.16,'Color',[0 0 0],'Linewidth',1,'LineStyle','--')
set(gcf, 'Position', [488,317,386.6,265.6]);

cfg.linecolor=[ .1 0.5 0.2;0.84 0.68 0.22];
ft_singleplotER(cfg,GA_4ft_smooth.AVC,GA_4ft_smooth.A); hold on; yline(0); xline(0);
set(gca,'xtick',0:0.1:0.4,'xticklabel',{0:100:400})
set(gca,'ytick',-2:2:2,'yticklabel',{-2:2:2})
xlabel('Time (ms)')
ylabel('TRF β')
set(gcf, 'Position', [488,438,237.8,144.6]);

cfg.linecolor=[ 0.635 0.078 0.184;0.84 0.68 0.22];
ft_singleplotER(cfg,GA_4ft_smooth.AVI,GA_4ft_smooth.A); hold on; yline(0); xline(0);
set(gca,'xtick',0:0.1:0.4,'xticklabel',{0:100:400})
set(gca,'ytick',-2:2:2,'yticklabel',{-2:2:2})
xlabel('Time (ms)')
ylabel('TRF β')
set(gcf, 'Position', [488,438,237.8,144.6]);


cfg.linecolor=[ 0.00,0.45,0.74;0.84 0.68 0.22];
ft_singleplotER(cfg,GA_4ft_smooth.V,GA_4ft_smooth.A); hold on; yline(0); xline(0);
set(gca,'xtick',0:0.1:0.4,'xticklabel',{0:100:400})
set(gca,'ytick',-2:2:2,'yticklabel',{-2:2:2})
xlabel('Time (ms)')
ylabel('TRF β')
set(gcf, 'Position', [488,438,237.8,144.6]);






set(gcf, 'Position', [488,438,237.8,144.6]);



%subplot(1,3,2)
cfg.linecolor=[.1 0.5 0.2; 0.635 0.078 0.184];
ft_singleplotER(cfg,GA_4ft_smooth.AVC,GA_4ft_smooth.AVI); hold on; yline(0); xline(0);set(gcf, 'Position', [488,438,237.8,144.6]);
%subplot(1,3,3)
cfg.linecolor=[.1 0.5 0.2; 0.84 0.68 0.22];
ft_singleplotER(cfg,GA_4ft_smooth.AVC,GA_4ft_smooth.A); hold on; yline(0); xline(0)
set(gcf, 'Position', [488,438,237.8,144.6]);

cfg.linecolor=[.1 0.5 0.2; 0.84 0.68 0.22; 0.00,0.45,0.74];%0.25 0.55 0.79];
ft_singleplotER(cfg,GA_4ft_smooth.AVC,GA_4ft_smooth.A,GA_4ft_smooth.V); hold on; yline(0); xline(0)
set(gcf, 'Position', [488,438,237.8,144.6]);



cfg=[];
%cfg.channel       = 'Fz';
cfg.ylim=[-2 3];
cfg.xlim=[-0.05 0.4];
cfg.linewidth=1;
%cfg.showlegend    = 'yes';
cfg.title=' ';
cfg.linecolor=[.1 0.5 0.2; 0.93,0.69,0.13];%0.84 0.68 0.22];

ft_multiplotER(cfg,GA_4ft.AVC,GA_4ft.A)%; hold on; yline(0); xline(0)
set(gcf, 'Position', [35.4,49.800000000000004,1436,828.8000000000001]);



plottimes=0:.0250:.200;
% Select condition, time point
newplots=[];
close all
newplots.AVC=erp_data(1,:,:);
newplots.A=erp_data(4,:,:);
newplots.diff=erp_data_diff(3,:,:);
plotnames=fieldnames(newplots);
counter=0;
for c=1:length(plotnames)
    for pt=1:length(plottimes)-1
        [~,pidx1]=min(abs(timeaxis-plottimes(pt)));
        [~,pidx2]=min(abs(timeaxis-plottimes(pt+1)));
        time_idx = pidx1;%:pidx2; % Midway in time
        % Extract data for the selected condition and time
        counter=counter+1;
       % topo_data = squeeze(mean(erp_data_diff(c, time_idx, :),2)); % 64 x 1 vector
        topo_data = squeeze(mean(newplots.(plotnames{c})(1,time_idx, :),2)); % 64 x 1 vector

        % Plot topographic map
        subplot(3,8,counter)
        h=topoplot(topo_data, chanlocs,'ColorMap',mycolors, 'maplimits', [-2 2],'style','map', 'electrodes', 'on',...
            'emarker' ,{'.','k',[],.1} ,'shading', 'interp');
       hold on
       h.MarkerSize=1;
        colormap(mycolors);
        colorbar;
        title([plotnames{c} ': ' num2str(plottimes(pt)) ' to ' num2str(plottimes(pt+1))])
    end
    %title(sprintf('ERP Topography - Condition %d, Time %d ms', condition, time_idx));
end
set(gcf, 'Position', [36.2,140.2,1452,704.8000000000001]);



plottimes=0:.0250:.200;
% Select condition, time point
condition = 1; % First condition
close all
counter=0;
for c=1:length(condnames)
    for pt=1:length(plottimes)-1
        [~,pidx1]=min(abs(timeaxis-plottimes(pt)));
        [~,pidx2]=min(abs(timeaxis-plottimes(pt+1)));
        time_idx = pidx1:pidx2; % Midway in time
        % Extract data for the selected condition and time
        counter=counter+1;
       % topo_data = squeeze(mean(erp_data_diff(c, time_idx, :),2)); % 64 x 1 vector
        topo_data = squeeze(mean(erp_data(c, time_idx, :),2)); % 64 x 1 vector

        % Plot topographic map
        subplot(5,8,counter)
        h=topoplot(topo_data, chanlocs,'ColorMap',mycolors, 'maplimits', [-2 2],'style','blank', 'electrodes', 'on',...
            'emarker' ,{'.','k',[],.1} ,'shading', 'interp');
       hold on
       h.MarkerSize=1;
        colormap(mycolors);
        colorbar;
        title([condnames{c} ': ' num2str(plottimes(pt)) ' to ' num2str(plottimes(pt+1))])
    end
    %title(sprintf('ERP Topography - Condition %d, Time %d ms', condition, time_idx));
end
set(gcf, 'Position', [36.2,140.2,1452,704.8000000000001]);






