% Function: Gammatone Filter
function filtered_signals = PLT_gammatone_filter(x, fs, center_freqs,D,num_bands)
% Fast gammatone filterbank implementation for speech envelope extraction
% Shared variable to track progress
progressArray = zeros(num_bands, 1);

num_bands = length(center_freqs);
filtered_signals = zeros(length(x), num_bands);
afterEach(D, @(~) fprintf('Progress: %d/%d completed\n', sum(progressArray), num_bands));

% Use parallel processing to filter multiple bands simultaneously
parfor i = 1:num_bands  % Use parfor for speedup on multi-core CPUs
    filtered_signals(:, i) = apply_gammatone(x, fs, center_freqs(i));

    % Mark progress
    progressArray(i) = 1;

    % Send an update to DataQueue
    send(D, i);
end

% % Gammatone filter implementation using a 4th-order filter
% erb = 24.7 * (4.37 * center_freq / 1000 + 1); % Equivalent Rectangular Bandwidth
% b = 1.019 * erb; % Bandwidth scaling factor
% t = (0:length(x)-1) / fs;
%
% % Complex impulse response of a gammatone filter
% impulse_response = t .^ 3 .* exp(-2 * pi * b * t) .* cos(2 * pi * center_freq * t);
%
% % Normalize energy and apply filter
% impulse_response = impulse_response / max(abs(impulse_response));
% y = filter(impulse_response, 1, x);

end





function y = apply_gammatone(x, fs, center_freq)
% Apply gammatone filter for a single frequency band
erb = 24.7 * (4.37 * center_freq / 1000 + 1);
b = 1.019 * erb;

% Design a short FIR gammatone filter (faster than full impulse response)
filter_order = round(fs / center_freq * 2); % Adaptive filter length
t = (0:filter_order-1) / fs;

% Compute impulse response
impulse_response = t .^ 3 .* exp(-2 * pi * b * t) .* cos(2 * pi * center_freq * t);
impulse_response = impulse_response / max(abs(impulse_response));  % Normalize

% Apply filter using fast convolution
y = filtfilt(impulse_response, 1, x);  % Zero-phase filtering for cleaner output
end