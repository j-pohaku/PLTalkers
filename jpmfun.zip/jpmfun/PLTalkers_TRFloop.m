


%% Notes

% Will run TRF on speech or bio-motion information using a variety of model
% training methods
% Method 1: Models trained within conditions separately
% Method 2: Models trained on one condition specifically
% Method 3: Models train across trials irrespective of condition labels



%% Setup

function [outmsg,runtime] = PLTalkers_TRFloop(readme)


datafolder=readme.datafolder;
setupfolder=readme.setupfolder;
finishfolder=readme.outputfolder;
subjectfolder=readme.datafolder;
%load('C:\Users\jpmomsen\Documents\Research\Projects\Diss_Study1\setup_files\bigsetup_38S1.mat')
%load([setupfolder 'contextcodespersub']);
%clearvars stiminfo5
%load([setupfolder 'bodylayout4plot']);
load([setupfolder 'tcd_chaninfo.mat']); % 37 chans
format long g

%load([setupfolder 'videoepochcount_38subs.mat']); % qp5, tlk4_14, tlk4_21 - abnormal # video onset codes
%load([setupfolder 'subtrial_acc_art']);
%load([setupfolder 'tlk4_bmotmaster']); % 17 OP locs
%load([setupfolder 'tlk4_bmotmaster_time']); % 17 OP locs







%% TRF loop

eeglab('nogui');

readmesave=readme;
subidx=dir(datafolder);
subidx = subidx(~ismember({subidx.name}, {'.', '..'}));
subidx = subidx(~contains({subidx.name}, '.fdt'));
subidx = subidx(contains({subidx.name}, readme.sets));

runtime=zeros(length(subidx),1);

% Loop through subjects
for s=readme.runsubs

    %  subjectfolder=([subidx(s).folder '/' subidx(s).name '/']);
    subID=strrep(subidx(s).name,'.set','');
   % subID=strrep(subID,readme.sets,'');
        subID=strrep(subID,'TCD_trfgo_epochICA_oldARTflags_yale_TCD_ICAepoched_yale_','');

    


    % load .set file
    fprintf('\n\n\n*** Loading condition 1 EEGLAB data from subject (%s) ***\n\n\n', s , subID);
    
        EEG = pop_loadset('filename', subidx(s).name,'filepath',subjectfolder);

    % EEG = pop_loadset('filename', ['TCD_ARTflag_' subID '.set' ],'filepath',subjectfolder);
    EEG = eeg_checkset( EEG ); % eeglab redraw
    
 % get index for trials with artifact flags
    artidx=find(EEG.reject.rejmanual==1);
    % load behdta
    readme.behdta=load([subjectfolder 'bdf' num2str(1) 'info_' subID '.mat']);

    if ~isequal(readme.trfnames_trinity{1},'resp')
        error('resp must be first entry in variable trfnames')
    end
    if ~isequal(readme.trfnames_aist{1},'resp')
        error('resp must be first entry in variable trfnames')
    end

    % Resample eeg
    if readme.resamp_sr== EEG.srate
    else
        % just resample EEG
        disp(['Resampling EEG...']);
        EEG = pop_resample( EEG, readme.resamp_sr);
        EEG = eeg_checkset( EEG );
        % eeglab redraw
    end

    % drop channels
    if isequal(readme.dropchans,'yes')
        EEG = pop_select( EEG, 'nochannel',readme.chans2drop); % 'T7','T8'
        EEG = eeg_checkset( EEG );
        %EEG.data([find(ismember(readme.allchans,readme.chans2drop))],:,:)=[];
    else
       % EEG.data([33 34 35 36 37],:,:)=[];
    end

   
    readme.trfchans=EEG.chanlocs;
    rejidx=unique((artidx));
    readme.artifactidx=artidx;
    readme.rejidx=rejidx;
    clearvars artidx  rejidx

    % Baseline EEG -500 to 0ms
    if isequal(readme.baselinetrls,'yes')
        EEGdatahold=EEG.data;
        baselineidxs=find((EEG.times==-500)):find((EEG.times==0));
        baselineidxs(end)=[];

        for i=1:size(EEGdatahold,3)
            for ch=1:size(EEGdatahold,1)
                EEGdatahold(ch,:,i)=EEGdatahold(ch,:,i)-mean(EEGdatahold(ch,baselineidxs,i));
            end
        end
        EEGdata=EEGdatahold;
        % EEGdata  =  jpmfun_baselineeeg(EEG,readme);
        EEG.data=EEGdata;
        clearvars EEGdata
    end

    % norm EEG
    if isequal(readme.normeeg,'yes')
        EEGdatahold=EEG.data;
        EEGdatahold(:,:,readme.rejidx)=[];
        tmp = reshape(EEGdatahold, [size(EEGdatahold,1) size(EEGdatahold, 2) * size(EEGdatahold, 3) ]);
        eegstd=std(tmp(:));
        for i=1:size(EEGdatahold,3)
            newEEG(:,:,i)=EEGdatahold(:,:,i)/eegstd;
        end
        EEGblank=zeros([size(EEG.data,1) , size(EEG.data, 2) , size(EEG.data, 3) ]);
        trls2save(1,1:size(EEG.data, 3))=1;
        trls2save(readme.rejidx)=0;
        c=0;
        for i=1:length(trls2save)
            if trls2save(i)==1
                c=c+1;
                EEGblank(:,:,i)=newEEG(:,:,c);
            else
                EEGblank(:,:,i)=EEGblank(:,:,i);
            end
        end
        EEGdata=EEGblank;
        %EEGdata  =  jpmfun_stdeeg(EEG,readme);
        EEG.data=EEGdata;
        clearvars EEGdata
    end

    % if s==17
    %     readme.behdta.bdfinfo.behdata=readme.behdta.bdfinfo.behdata([readme.behdta.bdfinfo.behdata.Block]~=6,:);
    % end

    if size(readme.behdta.bdfinfo.behdata,1)~=EEG.trials
        error('Number of trials in EEG structure do not match "behdata" rows')
    end

    % subidx has key for trials to include for each condition
    for i=1:length(EEG.epoch)
        readme.subidx{i,1}=num2str(EEG.epoch(i).eventtype{1,2});
        readme.subidx{i,2}=readme.behdta.bdfinfo.behdata.VideoPath(i);
        readme.subidx{i,3}=readme.behdta.bdfinfo.behdata.Block(i);
        readme.subidx{i,4}=readme.behdta.bdfinfo.behdata.conds(i);
        readme.subidx{i,5}=readme.behdta.bdfinfo.behdata.Trialcode(i);
        if s~=1
            readme.subidx{i,6}=readme.behdta.bdfinfo.behdata.key_resp_7_keys(i);
        else
            readme.subidx{i,6}=[];
        end
        if ~isempty(find(readme.rejidx==i))
            readme.subidx{i,7}='1'; % kept trial
        else
            readme.subidx{i,7}='0'; % kicked trial
        end
        readme.subidx{i,8}=num2str(i);
    end


    [trfhld,readme] = PLTalkers_getTCDstiminfo(readme,EEG,setupfolder); % trfhld here includes flagged trials
    %[trfhld,readme] = jpmfun_getTCDtrfhldUSE_simple(readme,EEG,setupfolder); % trfhld here includes flagged trials


    % get list of good trials for current condition (trllist)
    %{
     hold=subidx(find(contains(subidx(:,5),'c')),:);
     for i=1:length(hold)
         kill(i)=isequal(hold{i,3},'0');               
     end
     hold=hold(kill,:);
     trllist=hold;
     jpm.trllist.(cond_master_names{1})=trllist;
     clearvars hold kill
     hold=subidx(find(contains(subidx(:,5),'i')),:);
     for i=1:length(hold)
         kill(i)=isequal(hold{i,3},'0');               
     end
     hold=hold(kill,:);
     trllist_2=hold;
     jpm.trllist_2.(cond_master_names{2})=trllist_2;
     clearvars hold kill
    %}
tic;
    if isequal(readme.trfmethod,'all')
        [TRF_master_all] = PLTalkers_runTRFmultisensoryloop(readme,trfhld);
        %TRF_master_all = jpmfun_runTRFmultisensoryUSEALLCONDS_simple(readme,trfhld);
    end
disp(toc);

    if isequal(readme.trfmethod,'all4plot')
        TRF_master_all = PLTalkers_runTRFmultisensoryloop4plot(readme,trfhld);
        %TRF_master_all = jpmfun_runTRFmultisensoryUSEALLCONDS4PLOT_simple(readme,trfhld);
    end

     if isequal(readme.trfmethod,'byfreq')
        [TRF_master_all] = PLTalkers_runTRFmultisensoryloop_freqband(readme,trfhld);
        %TRF_master_all = jpmfun_runTRFmultisensoryUSEALLCONDS_simple(readme,trfhld);
     end

    %
    % if isequal(readme.trfmethod,'condition')
    %     TRF_master_all = jpmfun_runTRFallconditionsUSE(readme,trfhld);
    % end
    % if isequal(readme.trfmethod,'multisensory')
    %     TRF_master_all= jpmfun_runTRFmultisensoryUSE(readme,trfhld);
    % end


    TRF_master_all.readme=readme;



    save([finishfolder readme.saveTRFname subID '.mat'],'TRF_master_all');

    % kill subject-specific vars
    clearvars TRF_master_all
    clearvars readme
    readme=readmesave;
end % end subject loop


outmsg='Done';