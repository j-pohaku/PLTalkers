
function mybars = PLTalkers_barplotwdots(stimnames,condnames,condlabels,barColorMap,tblkeep,plotdots)


% Plot GA marginal means - envelope decoders
clearvars starbars starsig rhold namehold tblhold rholderr rholddots tblholdsub subsnames
for i=1:length(condnames)
    for st=1:length(stimnames.audio)
        tblhold=tblkeep.(condnames{i});
        subsnames=unique(tblhold.subID);
        tblhold(find(~ismember(tblhold.stimtype,stimnames.audio{st})),:)=[];
        for sub=1:length(unique(tblhold.subID))
            tblholdsub=tblhold;
            tblholdsub(find(~ismember(tblholdsub.subID,subsnames{sub})),:)=[];
            rholddots(sub,i)=mean(tblholdsub.test_r);
            clearvars tblholdsub
        end
        rhold(st,i)= mean(rholddots(:,i));%mean(tblhold.test_r);
        rholderr(st,i)=std(rholddots(:,i))/sqrt(length(rholddots(:,i)));%std(tblhold.test_r)/sqrt(length(tblhold.test_r));
        clearvars tblhold
    end
end

% Error bars indicate SEM across participants



clf;
for ii=1:length(condnames)
   % subplot(1,length(condnames),ii)
    h=bar(ii,rhold(1,ii),0.6);
    h(1).FaceColor=barColorMap{ii};
    hold on
    er = errorbar(ii,rhold(1,ii)',rholderr(1,ii)',rholderr(1,ii)');
    er.Color = [0 0 0];% [0.5 0.6 0.6]; grey
    er.LineStyle = 'none';
    er.LineWidth = 1;
    if isequal(plotdots,'yes')
   % er.XData = 0;
    scatter(repmat(ii,length(rholddots(:,ii)), 1),rholddots(:,ii),12,'MarkerFaceColor','k','MarkerEdgeColor','k','LineWidth',0.5,'XJitter','randn','XJitterWidth',.25)
    end
end
    %scatter(repmat(h(1).XEndPoints(1),length(rholddots(:,ii)), 1),rholddots(:,ii),10,'MarkerFaceColor','k','MarkerEdgeColor','k','LineWidth',0.5,'XJitter','randn','XJitterWidth',.25)
   % set(gca,'xtick',1,'xticklabel',condlabels{ii}),  grid on
    set(gca,'xtick',1:length(condnames),'xticklabel',condlabels),  grid on
 
    ylim([-0.025 0.2]),title('Mean Decoder Scores'), xlabel(' ')
    ylabel('Pearson Correlation')
    set(gcf, 'Position', [476,360,345,420]);


%set(gcf, 'Position', [216.2,203.4,965.5999999999999,309.6]);
%set(gcf, 'Position', get(0, 'Screensize'));


mybars='done';


 % Plot GA marginal means - envelope decoders
%     clearvars starbars starsig rhold namehold tblhold rholderr rholddots
%     for i=1:length(condnames)
%         for st=1:length(stimnames.audio)
%             tblhold=tblkeep.(condnames{i});
%             tblhold(find(~ismember(tblhold.stimtype,stimnames.audio{st})),:)=[];
%             rholddots(:,i)=tblhold.test_r;
%             rhold(st,i)= mean(tblhold.test_r);
%             rholderr(st,i)=std(tblhold.test_r)/sqrt(length(tblhold.test_r));
%             clearvars tblhold
%         end
%     end
%     bar(1:length(condnames),rhold(1,:)')
%     set(gca,'xtick',1:length(condnames),'xticklabel',condlabels), axis square, grid on
%     ylim([-0.05 0.2]),title(['Mean Performance']), xlabel('Parameter'), ylabel('Correlation')
%     title(stimnames.audio(1))
%     hold on
%     er = errorbar(1:length(condnames),rhold(1,:)',rholderr(1,:)',rholderr(1,:)');
%     er.Color = [0 0 0];
%     er.LineStyle = 'none';
%     hold off
%     sgtitle(loadname)
%     


%     clf;
% rng(pi) % just to reproduce the random data I used
% x=randi(2,10,1);
% y=rand(10,2)*6;
% h=bar([mean(y(x==1,:));mean(y(x==2,:))]');
% hold on
% h(1).FaceColor='r';
% h(2).FaceColor='y';
% errorbar(h(1).XEndPoints,mean(y(x==1,:)),std(y(x==1,:)),'LineStyle','none','Color','k','LineWidth',2)
% errorbar(h(2).XEndPoints,mean(y(x==2,:)),std(y(x==2,:)),'LineStyle','none','Color','k','LineWidth',2)
% % simple version
% % scatter(repmat(h(1).XEndPoints(1), sum(x==1), 1),y(x==1,1),60,'MarkerFaceColor','r','MarkerEdgeColor','k','LineWidth',1)
% % scatter(repmat(h(1).XEndPoints(2), sum(x==1), 1),y(x==1,2),60,'MarkerFaceColor','r','MarkerEdgeColor','k','LineWidth',1)
% % scatter(repmat(h(2).XEndPoints(1), sum(x==2), 1),y(x==2,1),60,'MarkerFaceColor','y','MarkerEdgeColor','k','LineWidth',1)
% % scatter(repmat(h(2).XEndPoints(2), sum(x==2), 1),y(x==2,2),60,'MarkerFaceColor','y','MarkerEdgeColor','k','LineWidth',1)
% % bonus version, it looks like the markers in your example have a tiny bit of
% % jitter. Starting in R2020b you can do this easily with scatter:
% scatter(repmat(h(1).XEndPoints(1), sum(x==1), 1),y(x==1,1),60,'MarkerFaceColor','r','MarkerEdgeColor','k','LineWidth',1,'XJitter','randn','XJitterWidth',.05)
% scatter(repmat(h(1).XEndPoints(2), sum(x==1), 1),y(x==1,2),60,'MarkerFaceColor','r','MarkerEdgeColor','k','LineWidth',1,'XJitter','randn','XJitterWidth',.05)
% %scatter(repmat(h(2).XEndPoints(1), sum(x==2), 1),y(x==2,1),60,'MarkerFaceColor','y','MarkerEdgeColor','k','LineWidth',1,'XJitter','randn','XJitterWidth',.05)
% %scatter(repmat(h(2).XEndPoints(2), sum(x==2), 1),y(x==2,2),60,'MarkerFaceColor','y','MarkerEdgeColor','k','LineWidth',1,'XJitter','randn','XJitterWidth',.05)
% xticklabels(["Left" "Right"])
% ylabel("Amplitude")

