

close all
clear
clc
cd C:\Users\jpmomsen\Documents\Research\Projects\Diss_Study23\TRF_EEG_analysis\
%cd F:\Fdrive_852022\JPM_dissertation\Diss_study23\
addpath(genpath('C:\Users\jpmomsen\Documents\Research\Projects\Diss_Study23\'))
addpath(genpath('C:\Users\jpmomsen\Documents\MATLAB\speechenv_toolbox'));
addpath(genpath('C:\Users\jpmomsen\Documents\MATLAB\mTRF-Toolbox-master'));
addpath(genpath('C:\Users\jpmomsen\Documents\MATLAB\mocaptoolbox-1.6.6'));
addpath('C:\Users\jpmomsen\Documents\MATLAB\eeglab\eeglab2022.1\');

datafolder='C:\Users\jpmomsen\Documents\Research\Projects\Diss_Study23\TRF_EEG_analysis\TCD_studydata\';
setupfolder='C:\Users\jpmomsen\Documents\Research\Projects\Diss_Study23\TRF_EEG_analysis\setupfiles\';

% Sub 005 and 007 have abnormal number of vid onset codes 
% Subs 001 and 002 have altered block onset codes 


% Tania workshop
% [ALLEEG EEG CURRENTSET ALLCOM] = eeglab;
% EEG = pop_biosig('C:\Users\jpmomsen\Documents\Research\Scripts\tania_eegworkshop\kirby_25.bdf', 'ref',[33 34] ,'bdfeventmode',[],'refoptions',{'keepref','off'});
% [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 0,'setname','BDFfilekirby25','gui','off'); 
% EEG = eeg_checkset( EEG );
% EEG = pop_select( EEG, 'nochannel',{'EXG6','EXG7','EXG8','GSR1','GSR2','Erg2','Resp','Plet','Temp'});
% [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 1,'gui','off'); 
% EEG = eeg_checkset( EEG );
% EEG=pop_chanedit(EEG, 'load',{'C:\\Users\\jpmomsen\\Documents\\Research\\Scripts\\tania_eegworkshop\\biosemi_channel_locations.sph.txt','filetype','sph'});
% [ALLEEG EEG] = eeg_store(ALLEEG, EEG, CURRENTSET);
% EEG = pop_eegfiltnew(EEG, 'locutoff',0.1,'hicutoff',30,'plotfreqz',1);
% [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 2,'gui','off');
% % EEG  = pop_basicfilter( EEG,  1:36 , 'Boundary', 'boundary', 'Cutoff',...
% % [ 0.1 30], 'Design', 'butter', 'Filter', 'bandpass', 'Order',...
% %   2 ); 
% EEG  = pop_creabasiceventlist( EEG , 'AlphanumericCleaning', 'on', 'BoundaryNumeric', { -99 }, 'BoundaryString',...
% { 'boundary' } ); % GUI: 14-Apr-2023 11:38:36
% EEG  = pop_binlister( EEG , 'BDF', 'C:\Users\jpmomsen\Documents\Research\Scripts\tania_eegworkshop\KIRBY_sample_bin_descriptor_file.txt',...
%  'IndexEL',  1, 'SendEL2', 'EEG', 'Voutput', 'EEG' ); % GUI: 14-Apr-2023 11:42:09
% EEG = pop_epochbin( EEG , [-200.0  800.0],  'pre'); % GUI: 14-Apr-2023 11:45:12
















%% BDFinfo and preprocessing loop

subidx=dir(datafolder);
subidx(1)=[];
subidx(1)=[];

% this will run ICA on continuous data
jpmcfg.runICA='no'; % 'yes'

jpmcfg.filthi=30;
jpmcfg.filtlo=0.1;
jpmcfg.resamp=64;

s=20;

% events2keep for each subject
    % sub005 = events2keep=([11:22 101 102 103 104 41])

% Loop through subjects 
for s=2:length(subidx)
     if s==5 || s==7
        continue
     end
% OR target 1 subject 
% s=9;

       subjectfolder=([subidx(s).folder '\' subidx(s).name '\']);
       subID=subidx(s).name;
        % pull each subj
        datalist=struct2cell(dir(subjectfolder))';


%%%%%%%%%%%%%%%%% load psychopy csv 
        findcsv=find(contains(datalist(:,1),'csv'));
        behdta=readtable([datalist{findcsv,2} '\' datalist{findcsv,1}]);
        %behdta=readtable([datalist{findcsv,2} '\' datalist{findcsv,1}],'VariableNamingRule','preserve');
        behdta(isnan(behdta.Trialcode),:)=[];
%%%%%%%%%%%%%%%%% load bdf into eeglab
              findbdf=find(contains(datalist(:,1),'.bdf'));


  % Sub 20 
  eeglab
  b=1;
  EEG = pop_loadset('filename','TCD_rawmerged_TCD_sub020bdf_1.set','filepath','C:\\Users\\jpmomsen\\Documents\\Research\\Projects\\Diss_study23\\TRF_EEG_analysis\\TCD_studydata\\TCD_sub020\\');

% EEG = pop_loadset('filename','TCD_raw_TCD_sub020bdf_1.set','filepath','C:\\Users\\jpmomsen\\Documents\\Research\\Projects\\Diss_study23\\TRF_EEG_analysis\\TCD_studydata\\TCD_sub020\\');
   eeglab redraw
   bdfinfo = jpmtcdfun_pullbdfinfo(EEG, behdta,subjectfolder,setupfolder,subID,b,jpmcfg);
   bdfinfo.file=[datalist{findbdf(b),2} '\' datalist{findbdf(b),1}];
   save([subjectfolder 'bdf' num2str(b) 'info_' subID '.mat'],'bdfinfo');

% EEG = pop_loadset('filename','TCD_raw_TCD_sub020bdf_2.set','filepath','C:\\Users\\jpmomsen\\Documents\\Research\\Projects\\Diss_study23\\TRF_EEG_analysis\\TCD_studydata\\TCD_sub020\\');




  % Grabbing about bdf files
for b=1:length(findbdf)
        [ALLEEG, EEG, CURRENTSET, ALLCOM] = eeglab;
        %eeglab
        eeglab('redraw');
        EEG = pop_biosig([datalist{findbdf(b),2} '\' datalist{findbdf(b),1}], 'ref',[33 34]);
        %EEG = pop_biosig([subdatalist(2).folder '\' subdatalist(2).name ], 'ref',[33 34]);
        %[ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 0,'setname','BDFfile_pilot1','comments',strvcat('Original file:','F:\\Fdrive_852022\\JPM_dissertation\\Diss_study23\\data\\Testdata.bdf'),'gui','off'); 
        eeglab redraw
   bdfinfo = jpmtcdfun_pullbdfinfo(EEG, behdta,subjectfolder,setupfolder,subID,b,jpmcfg);
   bdfinfo.file=[datalist{findbdf(b),2} '\' datalist{findbdf(b),1}];
   save([subjectfolder 'bdf' num2str(b) 'info_' subID '.mat'],'bdfinfo');
end
            % plot event timeline
            %{
                    codes2find=[101;102;103;104];
                    %codes2find=[41];
                    blocks2find=[11:1:20];
                    eventplot=zeros(1,length(EEG.times));
                        for i=1:length(bdfinfo.rawevents)
                            if sum(bdfinfo.rawevents(i).edftype==blocks2find)>0
                               eventplot(1,round(bdfinfo.rawevents(i).latency))=10;
                            end
                            if sum(bdfinfo.rawevents(i).edftype==codes2find)>0
                               eventplot(1,round(bdfinfo.rawevents(i).latency))=5;
                            end
                        end
                      blockstarts=find(eventplot==10);
                      vidstarts=find(eventplot==5);
                      for i=1:length(blockstarts)
                          if i<length(blockstarts)
                            vidcounts(i)= sum(blockstarts(i+1)>vidstarts & vidstarts>blockstarts(i));
                          else
                            vidcounts(i)= sum( vidstarts>blockstarts(i));
                          end
                      end
                        h=figure, set(h,'Position',[40 200 560 420])
                        plot(EEG.times/1000,eventplot)
                        xlabel('Time (s)')
                        ylabel('Blocks and video onsets')
                        dim = [.2 .5 .3 .3];
                        str =['Vid onsets per block ' num2str(vidcounts) ] ;
                        %str =['Vid offsets per block ' num2str(vidcounts) ] ;
                        annotation('textbox',dim,'String',str,'FitBoxToText','on');
                        clearvars vids2find blocks2find eventplot blockstarts vidstarts vidcounts
            %}

end




%% ICA and ARTflag loop
clearvars
clc
datafolder='C:\Users\jpmomsen\Documents\Research\Projects\Diss_Study23\TRF_EEG_analysis\TCD_studydata\';
setupfolder='C:\Users\jpmomsen\Documents\Research\Projects\Diss_Study23\TRF_EEG_analysis\TCD_studydata\setupfiles\';

subidx=dir(datafolder);
subidx(1)=[];
subidx(1)=[];

jpmcfg.runICA='yes';
jpmcfg.runARTflag='no';
jpmcfg.dropICs='no';
jpmcfg.flagARTs='no';
jpmcfg.runautoARTflag='no';

s=20;

% Loop through subjects - run ICA or ARTflagging
for s=1:length(subidx)
   
       subjectfolder=([subidx(s).folder '\' subidx(s).name '\']);
       subID=subidx(s).name;
       datalist=struct2cell(dir(subjectfolder))';
       findbdfinfo=find(contains(datalist(:,1),'info_TCD_sub'));
%         if length(findbdfinfo)>1
% 
%         else
%           load([datalist{findbdfinfo(1),2} '\' datalist{findbdfinfo(1),1}]);
%         end

        [ALLEEG, EEG, CURRENTSET, ALLCOM] = eeglab;
        EEG = pop_loadset('filename',['TCD_preARTflag_' subID 'bdf_' num2str(1) '.set'],'filepath',subjectfolder);
        [ALLEEG, EEG, CURRENTSET] = eeg_store( ALLEEG, EEG, 0 );
        EEG = eeg_checkset( EEG );
        eeglab redraw

        % s=17 fixes
        % Line noise in f3 during block 7
        EEG.reject.rejmanual(1:185)=false;
        EEG.reject.rejmanual(84:102)=1;
        % EEG = pop_syncroartifacts(EEG, 3); % GUI: 15-Nov-2023 16:14:10
        EEG = pop_rejepoch( EEG, [84:102] ,0);
        EEG = eeg_checkset( EEG );
        eeglab redraw

 ARTflaginfo = jpmtcdfun_ICA_ARTflag(EEG,subjectfolder,setupfolder,subID,jpmcfg);
 ARTflaginfo.file=[datalist{findbdfinfo(1),2} '\' datalist{findbdfinfo(1),1}];
 save([subjectfolder 'ARTflaginfo_' subID '.mat'],'ARTflaginfo');
end



%% Manual ICA inspection 
clearvars
clc
datafolder='C:\Users\jpmomsen\Documents\Research\Projects\Diss_Study23\TRF_EEG_analysis\TCD_studydata\';
setupfolder='C:\Users\jpmomsen\Documents\Research\Projects\Diss_Study23\TRF_EEG_analysis\TCD_studydata\setupfiles\';

subidx=dir(datafolder);
subidx(1)=[];
subidx(1)=[];

    % OR target 1 subject 
    % s=20;
% Loop through subjects - run ICA or ARTflagging
for s=7:length(subidx)
       subjectfolder=([subidx(s).folder '\' subidx(s).name '\']);
       subID=subidx(s).name;
       datalist=struct2cell(dir(subjectfolder))';

       findbdfinfo=find(contains(datalist(:,1),'info_TCD_sub'));
        [ALLEEG, EEG, CURRENTSET, ALLCOM] = eeglab;

        EEG = pop_loadset('filename',['TCD_ICA_' subID '.set'],'filepath',subjectfolder);
        [ALLEEG, EEG, CURRENTSET] = eeg_store( ALLEEG, EEG, 0 );
        EEG = eeg_checkset( EEG );
        eeglab redraw

        pop_topoplot(EEG, 0, [1:36] , [subID '_epochs'],[6 6] ,0,'electrodes','on');


           % sub002: EEG = pop_subcomp( EEG, [1  2  5], 0);
           % sub003: EEG = pop_subcomp( EEG, [1  3  5 6 7], 0);
% 4/19/23
           % sub003: EEG = pop_subcomp( EEG, [2 5 6], 0);
           % sub004: EEG = pop_subcomp( EEG, [1 2 3 4 5 6 7], 0);
           % sub005: EEG = pop_subcomp( EEG, [1 2 3 4 5 6 ], 0);

           % sub006: EEG = pop_subcomp( EEG, [2 3 4], 0);
           % sub007: EEG = pop_subcomp( EEG, [1 4], 0);

           % sub008: EEG = pop_subcomp( EEG, [1 7], 0);

           % sub017: EEG = pop_subcomp( EEG, [1 2 3 4 5 6 7], 0); 
           % disp(find(EEG.reject.rejmanual==1))      8    44    68   134   157
           % sub018: EEG = pop_subcomp( EEG, [1 2 3 4 5], 0); 
           % disp(find(EEG.reject.rejmanual==1))     143   152 
           % sub019: EEG = pop_subcomp( EEG, [1 2 3  7], 0); 
           % disp(find(EEG.reject.rejmanual==1))      NONE

           % sub020: EEG = pop_subcomp( EEG, [1 3], 0);


EEG.reject.rejmanual(3)=EEG.reject.rejmanual(2);
EEG.reject.rejmanual(3)=true;

EEG.reject.rejmanual([8    44    68   134   157])=true;


% Save .set
         disp(['Saving ICAremov.set...']);
                EEG = pop_saveset( EEG, 'filename',['TCD_ICAremov_' subID '.set'],'filepath',subjectfolder);
                %[ALLEEG EEG] = eeg_store(ALLEEG, EEG, CURRENTSET);
                EEG = eeg_checkset( EEG );
                eeglab redraw

     % manual artifact flagging - click reject and then NO to populate
     % EEG.reject.rejmanual

            pop_eegplot( EEG, 1, 1, 0); % Plot to update marks

            disp(find(EEG.reject.rejmanual==1));

            % sub002:
            % sub003: Flagged 26    76    81    95   105   165   173   175
                    % small blinks = 14, 17, 21, 32, 46, 75, 80, 84, 96, 106, 111, 122, 123, 126, 132, 134, 135, 155, 164, 185
                    % some drift = 40, 42, 49, 85, 117, 125 
                    % 51 - teaching example - dont reject
                    
            % sub020:33    63    73    83   152   161   163   164   167   169   182

                    % Save .set
         disp(['Saving ARTflagged.set...']);
                EEG = pop_saveset( EEG, 'filename',['TCD_ARTflag_' subID '.set'],'filepath',subjectfolder);
                %[ALLEEG EEG] = eeg_store(ALLEEG, EEG, CURRENTSET);
                EEG = eeg_checkset( EEG );
                eeglab redraw

end











%% Unused code


% 
% 
% subidx=dir(datafolder);
% subidx(1)=[];
% subidx(1)=[];
% 
% 
% 
% % Loop through subjects 
% for s=1:length(subidx)
%        subjectfolder=([subidx(s).folder '\' subidx(s).name '\']);
%        subID=subidx(s).name;
% 
% end
% 
% 

%{

%% Assess raw bdf with psychopy log file

%%%%%%%%%%%%%%%%%% load psychopy run file
                opts = delimitedTextImportOptions("NumVariables", 3);
                % Specify range and delimiter
                opts.DataLines = [1, Inf];
                opts.Delimiter = "\t";
                % Specify column names and types
                opts.VariableNames = ["time", "type", "info"];
                opts.VariableTypes = ["double", "string", "string"];
                % Specify file level properties
                opts.ExtraColumnsRule = "ignore";
                opts.EmptyLineRule = "read";
                % Specify variable properties
                opts = setvaropts(opts, "info", "WhitespaceRule", "preserve");
                opts = setvaropts(opts, ["type", "info"], "EmptyFieldRule", "auto");
% Import the data
%psychopyrun_log=readtable([subdatalist(5).folder '\' subdatalist(5).name],opts);
psychopyrun_log=readtable([datalist(5).folder '\' datalist(5).name],opts);

clearvars opts

%Find video onset/offsets
        for i=1:size(psychopyrun_log,1)
            trlfind(i)=contains(char(psychopyrun_log{i,3}),'stim_movie: movie = ');
        end
        log_vidonsets=psychopyrun_log(find(double(trlfind)==1)',:);
        clearvars trlfind
        for i=1:size(psychopyrun_log,1)
            trlfind(i)=contains(char(psychopyrun_log{i,3}),'Set stim_movie finished');
        end
        log_vidoffsets=psychopyrun_log(find(double(trlfind)==1)',:);
        clearvars trlfind
        log_vidoffsets=table2cell(log_vidoffsets);
        log_vidonsets=table2cell(log_vidonsets);
% Find key responses 
        for i=1:size(psychopyrun_log,1)
            trlfind(i)=contains(char(psychopyrun_log{i,3}),'Keypress: ');
        end
        log_keypress=psychopyrun_log(find(double(trlfind)==1)',:);
        clearvars trlfind

%psychopyrun_csv=readmatrix([subdatalist(4).folder '\' subdatalist(4).name]);
%psychopyrun_log=readmatrix([subdatalist(5).folder '\' subdatalist(5).name]);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% comparing bdf and psychopy info

%compare vid offset eeg and log times 
        for i=1:length(log_vidoffsets)
           holder(i,1)=(log_vidoffsets{i,1});
        holder(i,2)=jpm.eegeventtimes.code_41(i);
        end
        %holder=abs(holder(:,1)-holder(:,2));
        jpm.eeglogoffset=holder(:,1)-holder(:,2);
        holderdiff=diff(holder);
        holderdiff=abs(holderdiff(:,1)-holderdiff(:,2));
        clearvars holder holderdiff
%compare vid onset eeg and log times 
        for i=1:length(log_vidonsets)
        holder(i,1)=(log_vidonsets{i,1});
       % holder(i,2)=jpm.eegeventtimes.code_41(i);
        end
        holderdiff=diff(holder);
        holderdiff=abs(holderdiff(:,1)-holderdiff(:,2));


% clearvars trlfind
% for i=1:size(studyevents,2)
%      trlfind(i)=contains(studyevents(i).type, '10');
% end 
% typefind=find(double(trlfind)==1)';
% for i=1:length(typefind)
%         eeg_vidonsets(i)=studyevents(typefind(i)).latency/EEG.srate;
% end
%  studyevents(2).latency/EEG.srate
% eeg_vidonsets = studyevents(~[studyevents.isdir]);



 %load block 1 info 
 readtable([])






%% Assess jpmsave, ie, how many trials removed during ASR

%   load([datafolder 'jpmsave_38subs']);% Burst criterion @ 25 - removed too many
%   load([datafolder 'jpmsave_6subs_30ASR']);% Burst criterion @ 25 - removed too many
%   load([datafolder 'jpmsave_32subs_30ASR']);% Burst criterion @ 25 - removed too many
    load([datafolder 'jpmsave_38subs_30ASR']);% Burst criterion @ 25 - removed too many

% hold=jpmsave;
% fn=fieldnames(hold);
% for i=2:7
% jpmsave.(fn{i})=hold.(fn{i});
% end
% jpmsave=orderfields(jpmsave);
% subject_list=fieldnames(jpmsave);

clearvars hold
for s=1:length(subject_list)
        if s>13
            subject = subject_list{s};
            newsubject = strrep(subject,'-','_');
        else 
            subject = subject_list{s};
            newsubject = subject_list{s};
        end

clearvars index878 index51 index40 index45
[index878,~] = find(strcmp(jpmsave.(newsubject).toteventcount, 'code_878'));
[index40,~] = find(strcmp(jpmsave.(newsubject).toteventcount, 'code_40'));
[index51,~] = find(strcmp(jpmsave.(newsubject).toteventcount, 'code_51'));
[index45,~] = find(strcmp(jpmsave.(newsubject).toteventcount, 'code_45'));
   hold(s,1) =jpmsave.(newsubject).toteventcount{index878,2};
   hold(s,2) =jpmsave.(newsubject).toteventcount{index40,2};
   hold(s,3) =jpmsave.(newsubject).toteventcount{index51,2};
   hold(s,4) =jpmsave.(newsubject).toteventcount{index45,2};
if isfield(jpmsave.(newsubject),'warning')==0
   hold(s,5)=length(jpmsave.(newsubject).precleanEEG.event);
   hold(s,6) =jpmsave.(newsubject).cleanedinfo.fullvidcount;
else
       hold(s,5)=0;
       hold(s,6) =0;
 %~isequal(hold(s,1),140) || ~isequal(hold(s,2),140) || ~isequal(hold(s,3),140) || ~isequal(hold(s,4),140)
end
        hold(s,7) =hold(s,6)/hold(s,1); % percentage trials kept after ASR rejection
end




%% Assess jpmsave, ie, how many trials removed during ASR

%   load([datafolder 'jpmsave_38subs']);% Burst criterion @ 25 - removed too many
%   load([datafolder 'jpmsave_6subs_30ASR']);% Burst criterion @ 25 - removed too many
%   load([datafolder 'jpmsave_32subs_30ASR']);% Burst criterion @ 25 - removed too many
    load([datafolder 'jpmsave_38subs_30ASR']);% Burst criterion @ 25 - removed too many

% hold=jpmsave;
% fn=fieldnames(hold);
% for i=2:7
% jpmsave.(fn{i})=hold.(fn{i});
% end
% jpmsave=orderfields(jpmsave);
% subject_list=fieldnames(jpmsave);

clearvars hold
for s=1:length(subject_list)
        if s>13
            subject = subject_list{s};
            newsubject = strrep(subject,'-','_');
        else 
            subject = subject_list{s};
            newsubject = subject_list{s};
        end

clearvars index878 index51 index40 index45
[index878,~] = find(strcmp(jpmsave.(newsubject).toteventcount, 'code_878'));
[index40,~] = find(strcmp(jpmsave.(newsubject).toteventcount, 'code_40'));
[index51,~] = find(strcmp(jpmsave.(newsubject).toteventcount, 'code_51'));
[index45,~] = find(strcmp(jpmsave.(newsubject).toteventcount, 'code_45'));
   hold(s,1) =jpmsave.(newsubject).toteventcount{index878,2};
   hold(s,2) =jpmsave.(newsubject).toteventcount{index40,2};
   hold(s,3) =jpmsave.(newsubject).toteventcount{index51,2};
   hold(s,4) =jpmsave.(newsubject).toteventcount{index45,2};
if isfield(jpmsave.(newsubject),'warning')==0
   hold(s,5)=length(jpmsave.(newsubject).precleanEEG.event);
   hold(s,6) =jpmsave.(newsubject).cleanedinfo.fullvidcount;
else
       hold(s,5)=0;
       hold(s,6) =0;
 %~isequal(hold(s,1),140) || ~isequal(hold(s,2),140) || ~isequal(hold(s,3),140) || ~isequal(hold(s,4),140)
end
        hold(s,7) =hold(s,6)/hold(s,1); % percentage trials kept after ASR rejection
end

%% Remove ICA components and auto artifact flag

clear
clc
cd 'C:\Users\jpmomsen\Documents\Research\Projects\Diss_Study1\';
 addpath('C:\Users\jpmomsen\Documents\MATLAB\fieldtrip-master\fieldtrip-master\')
 addpath('C:\Users\jpmomsen\Documents\MATLAB\eeglab\EEGLAB2022.1\')
  addpath('C:\Users\jpmomsen\Documents\MATLAB\speechenv_toolbox\')
 % addpath('C:\Users\jpmomsen\Documents\MATLAB\speechenv_toolbox\') mTRF?
 openfolder = 'C:\Users\jpmomsen\Documents\Research\Projects\Diss_Study1\';
 addpath(genpath(openfolder));
load('C:\Users\jpmomsen\Documents\Research\Projects\Diss_Study1\setup_files\bigsetup_38S1.mat')
format long g

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
runname=1;
ICAlist=jpmfun_getICAlist(numsubjects,runname);

cfgjpm.jpmsavename='jpmsave_38subs_ARTchecknoz';
 cfgjpm.setsavename ='_ARTflagsnoz';
%  cfgjpm.art_stepth=10; % 100 for non z
%   cfgjpm.art_wmth=7; % 70 for non z % MOVING WINDOW
%  cfgjpm.art_ws=300; % windowsize
%   cfgjpm.art_wst=50; % windowstep
%  cfgjpm.art_tw=[ 0  8000];
%  cfgjpm.art_rate=5;

  cfgjpm.art_stepth=100; % 100 for non z
  cfgjpm.art_wmth=100; % 70 for non z % MOVING WINDOW
 cfgjpm.art_ws=200; % windowsize
  cfgjpm.art_wst=50; % windowstep
 cfgjpm.art_tw=[ 0  8000];
 cfgjpm.art_rate=5;

% histogram(cell2mat(stimlengths280(:,2)),1000)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%{
ICAlist=zeros(numsubjects,10);
ICAlist(1,1:4 )=[1 2 3 4];
ICAlist(2,1:2)=[1 4];
ICAlist(3,1:3)=[3 4 7];
ICAlist(4,1:4)=[1 4 5 6];
ICAlist(5,1:3)=[1 3 4];
ICAlist(6,1:3)=[1 4 7];
ICAlist(7,1:3)=[1 3 8];
ICAlist(8,1:4)=[1 2 6 7];
ICAlist(9,1:4)=[2 4 5 6];
ICAlist(10,1:4)=[1 4 5 6];
ICAlist(11,1:3)=[3 4 5];
ICAlist(12,1:2)=[2 3];
ICAlist(13,1:3)=[1 3 5];
ICAlist(14,1:3)=[1 2 5];
ICAlist(15,1:5)=[1 2 3 4 5];
ICAlist(16,1:3)=[1 5 6];
ICAlist(17,1:2)=[1 2];
ICAlist(18,1:3)=[1 2 4];
ICAlist(19,1:3)=[1 3 4];
ICAlist(20,1:4)=[1 2 3 4];
ICAlist(21,1:3)=[1 2 4];
ICAlist(22,1:3)=[1 2 7];
ICAlist(23,1:3)=[2 3 4];
ICAlist(24,1:4)=[1 2 3 5];
ICAlist(25,1)=[1];
ICAlist(26,1:4)=[1 3 5 6];
ICAlist(27,1:3)=[3 4 5];
ICAlist(28,1:4)=[1 4 5 6];
ICAlist(29,1:2)=[1 2];
ICAlist(30,1:3)=[1 2 5];
ICAlist(31,1:4)=[1 3 5 6];
ICAlist(32,1:3)=[1 3 5];
ICAlist(33,1:3)=[1 5 6];
ICAlist(34,1:4)=[1 3 5 6];
ICAlist(35,1:4)=[1 3 5 6];
ICAlist(36,1:3)=[1 2 3];
ICAlist(37,1:2)=[2 3];
ICAlist(38,1:2)=[1 3];
%}

for s=1:length(subject_list)

%subjectfolder = [parentfolder subject '\'];
        if s<26
            subject = subject_list{s};
            newsubject = strrep(subject,'-','_');
        else 
            subject = subject_list{s};
            newsubject = subject_list{s};
        end
eeglab
fprintf('\n\n\n*** Processing subject %d(%s) ***\n\n\n', s, subject);
%EEG = pop_loadset('filename',[subject '.set'],'filepath',datafolder);
EEG = pop_loadset('filename',[newsubject '_ICA.set'],'filepath',datafolder);
%EEG = pop_loadset('filename',['tlk4_15_tester_resampfilt.set'],'filepath',datafolder);
EEG = eeg_checkset( EEG );
eeglab redraw
erplab redraw

killICA=(ICAlist(s,:));
killICA = nonzeros(killICA)';
EEG = pop_subcomp( EEG, killICA, 0); 
EEG = eeg_checkset( EEG );
eeglab redraw
erplab redraw
% 
% EEG = pop_epoch( EEG, eventcodelist, [-0.5  8], 'newname', [newsubject '_epochs'], 'epochinfo', 'yes');
% %[ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 5,'gui','off');
% EEG = eeg_checkset( EEG );
% eeglab redraw
% 
% EEG = pop_epoch( EEG, {'45'}, [-0.5  8], 'newname', [newsubject '_epochs'], 'epochinfo', 'yes');
% [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 5,'gui','off');
% EEG = eeg_checkset( EEG );
% eeglab redraw

% 40 launch 878 pacer 1000-6692 words 45 i1 51 vidoff
%     
% tmp = reshape(EEG.data, [size(EEG.data,1) size(EEG.data, 2) * size(EEG.data, 3) ]);
% [jpm.Z,jpm.mu,jpm.sigma] = zscore(tmp, 0, 2);
% tmp = reshape(jpm.Z, size(EEG.data));
% EEG.data = tmp;
% clearvars tmp

% plot(EEG.data)
% plot(tmp)

% COMMENTED LINE 343 and 301 in pop_artstep
% COMMENTED LINE 300 and 343 in pop_artmwppth
% 318 276 in pop_artderiv

[EEG]  = pop_artstep( EEG,'Channel',1:31,'Flag',1,'Threshold', cfgjpm.art_stepth, 'Twindow', cfgjpm.art_tw, 'Windowsize',  cfgjpm.art_ws, 'Windowstep', cfgjpm.art_wst);
    jpm.artstepkill=find(sum(EEG.reject.rejmanualE,1)~=0);
    jpm.artstepperc=   length(jpm.artstepkill)/EEG.trials;
    EEG  = pop_resetrej( EEG , 'ResetArtifactFields', 'on' ); % GUI: 23-Dec-2022 16:02:45
[EEG]  = pop_artmwppth( EEG , 'Channel',  1:31, 'Flag', 2, 'Threshold',  cfgjpm.art_wmth, 'Twindow',  cfgjpm.art_tw, 'Windowsize',  cfgjpm.art_ws, 'Windowstep', cfgjpm.art_wst);
    jpm.artmwppthkill=find(sum(EEG.reject.rejmanualE,1)~=0);
    jpm.artmwppthperc=  length(jpm.artmwppthkill)/EEG.trials;
    EEG  = pop_resetrej( EEG , 'ResetArtifactFields', 'on' ); % GUI: 23-Dec-2022 16:02:45
[EEG]  = pop_artderiv( EEG , 'Channel',  1:31, 'Flag',  3, 'Rate',  5, 'Twindow',  cfgjpm.art_tw );
    jpm.artderivkill=find(sum(EEG.reject.rejmanualE,1)~=0);
    jpm.artderivperc = length( jpm.artderivkill)/EEG.trials;
    EEG  = pop_resetrej( EEG , 'ResetArtifactFields', 'on' ); % GUI: 23-Dec-2022 16:02:45

    jpm.totartperc= length(unique(horzcat(jpm.artstepkill, jpm.artmwppthkill, jpm.artderivkill)))/EEG.trials;
    jpm.remainingtrials = EEG.trials-length(unique(horzcat(jpm.artstepkill, jpm.artmwppthkill, jpm.artderivkill)));
[EEG]  = pop_artstep( EEG,'Channel',1:31,'Flag',1,'Threshold', cfgjpm.art_stepth, 'Twindow', cfgjpm.art_tw, 'Windowsize',  cfgjpm.art_ws, 'Windowstep',cfgjpm.art_wst);
[EEG]  = pop_artmwppth( EEG , 'Channel',  1:31, 'Flag', 2, 'Threshold',  cfgjpm.art_wmth, 'Twindow',  cfgjpm.art_tw, 'Windowsize',  cfgjpm.art_ws, 'Windowstep',cfgjpm.art_wst);
[EEG]  = pop_artderiv( EEG , 'Channel',  1:31, 'Flag',  3, 'Rate',  cfgjpm.art_rate, 'Twindow',  cfgjpm.art_tw );

%EEG = pop_syncroartifacts(EEG, 3); % GUI: 23-Dec-2022 16:34:26
%[ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 1,'gui','off');
% Clear artifact flags
%       EEG  = pop_resetrej( EEG , 'ResetArtifactFields', 'on' ); % GUI: 23-Dec-2022 16:02:45



% 
% tmp = reshape(EEG.data, [size(EEG.data, 1) size(EEG.data, 2) * size(EEG.data, 3) ]);
% multy = (tmp.*jpm.sigma)+jpm.mu;
% tmp = reshape(multy, size(EEG.data));
% EEG.data = tmp;
% clearvars tmp


[ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 2,'savenew',[datafolder  newsubject cfgjpm.setsavename '.set'],'gui','off'); 
EEG = eeg_checkset( EEG );
eeglab redraw
EEG = pop_saveset( EEG, 'filename',[newsubject  cfgjpm.setsavename  '.set'],'filepath',datafolder);
[ALLEEG EEG] = eeg_store(ALLEEG, EEG, CURRENTSET);
clear eeglab

jpm.cfgjpm=cfgjpm;
jpmsave_ARTflags.(newsubject)=jpm;
clearvars jpm ICAkill 
end

save([datafolder cfgjpm.jpmsavename], 'jpmsave_ARTflags' );

% ARTcheck3 = ARTflagsuse


%% Assess ART flags and combine with beh perf info 


clear
clc
cd 'C:\Users\jpmomsen\Documents\Research\Projects\Diss_Study1\';
load('C:\Users\jpmomsen\Documents\Research\Projects\Diss_Study1\setup_files\bigsetup_38S1.mat')
format long g

% mean ICA components removed = 3.16; stddev = 0.823

%         for i=1:length(ICAlist)
%             icacount(i)= length(find(ICAlist(i,:)~=0));
%         end
%         mean(icacount)
%         std(icacount)

load([datafolder 'jpmsave_38subs_ARTcheck4']); % linked to use4.set
% total remaining trials = 3587
% avg percent trials remaining per sub = 67.4%
% stddev trials remaining per sub = 18.9%
% avg trials rejected per sub 45.6; stddev = 26.45
% avg percent trials rejected per sub = 32.6%; stddev = 18.9%
        % stepth = 10
        % wmth = 7
        % ws = 300ms; wst = 50ms
        % tw= 0 8000ms
        % rate = 5

 load([datafolder 'jpmsave_38subs_ARTcheck3']); % linked to use.set
% total remaining trials =4176
% avg percent trials remaining per sub = 78.5%; stddev = 13.78%
% avg trials rejected per sub 30.1; stddev = 19.29
% avg percent trials rejected per sub = 21.5%; stddev = 13.78%
        % stepth = 10
        % wmth = 8
        % ws = 300ms; wst = 50ms
        % tw= 0 8000ms
        % rate = 5

        load([datafolder 'jpmsave_38subs_ARTchecknoz']); % linked to use4.set


clearvars hold

for s=1:numsubjects

%subjectfolder = [parentfolder subject '\'];
        if s<26
            subject = subject_list{s};
            newsubject = strrep(subject,'-','_');
        else 
            subject = subject_list{s};
            newsubject = subject_list{s};
        end


if isempty(jpmsave_ARTflags.(newsubject).artderivperc)
hold(s,1)=nan;
else
hold(s,1)=jpmsave_ARTflags.(newsubject).artderivperc;
end

if isempty(jpmsave_ARTflags.(newsubject).artmwppthperc)
hold(s,2)=nan;
else
hold(s,2)=jpmsave_ARTflags.(newsubject).artmwppthperc;
end

if isempty(jpmsave_ARTflags.(newsubject).artstepperc)
hold(s,3)=nan;
else
hold(s,3)=jpmsave_ARTflags.(newsubject).artstepperc;
end

if isempty(jpmsave_ARTflags.(newsubject).remainingtrials)
hold(s,4)=nan;
else
hold(s,4)=jpmsave_ARTflags.(newsubject).remainingtrials;
end

hold(s,5)=(hold(s,4)/140);
hold(s,6)=(140-hold(s,4));
hold(s,7)=(hold(s,6)/140);

end


ARTinfo_noz=hold;

ARTinfo_use=hold;
ARTinfo_use4=hold;

hold(:,1)=ARTinfo_use(:,6);
hold(:,2)=ARTinfo_use4(:,6);
hold(:,3)=ARTinfo_noz(:,6);
hold(:,4)=SIGMAsub;

% look at manart trials below
clearvars hold
for s=1:numsubjects
    if s==16
        continue 
    end
        if s<26
            subject = subject_list{s};
            newsubject = strrep(subject,'-','_');
        else 
            subject = subject_list{s};
            newsubject = subject_list{s};
        end


        load([datafolder newsubject '_MANART']); % linked to use4.set
hold(s,1)=cfgjpm.sumrejauto;
hold(s,2)=cfgjpm.sumrejman;
hold(s,3)=cfgjpm.sumrejauto/140;
hold(s,4)=cfgjpm.sumrejman/140;
end

hold(16,:)=[];
mean(hold,1)


% col 1-3 perc trials eliminated by algorithm; col 4 = remaining trls 
% 
% sum(hold(:,4))
% mean(hold(:,5))
% std(hold(:,5))

hold_check4=hold;

hold_check3=hold;


sum(hold_check4(:,4))
mean(hold_check4(:,5))
std(hold_check4(:,5))
mean(hold_check4(:,6))
std(hold_check4(:,6))
mean(hold_check4(:,7))
std(hold_check4(:,7))

sum(hold_check3(:,4))
mean(hold_check3(:,5))
std(hold_check3(:,5))
mean(hold_check3(:,6))
std(hold_check3(:,6))
mean(hold_check3(:,7))
std(hold_check3(:,7))








%components2remove = jpmfun_assessICA(subject_list,filenames,datafolder);



%%  Remove ICA components and MANUAL artifact flag


% load([datafolder 'tlk4_5_MANART']);
% load([datafolder 'tlk4_12_MANART']);

clear
clc
cd 'C:\Users\jpmomsen\Documents\Research\Projects\Diss_Study1\';
 addpath('C:\Users\jpmomsen\Documents\MATLAB\fieldtrip-master\fieldtrip-master\')
 addpath('C:\Users\jpmomsen\Documents\MATLAB\eeglab\EEGLAB2022.1\')
  addpath('C:\Users\jpmomsen\Documents\MATLAB\speechenv_toolbox\')
 % addpath('C:\Users\jpmomsen\Documents\MATLAB\speechenv_toolbox\') mTRF?
 openfolder = 'C:\Users\jpmomsen\Documents\Research\Projects\Diss_Study1\';
 addpath(genpath(openfolder));
load('C:\Users\jpmomsen\Documents\Research\Projects\Diss_Study1\setup_files\bigsetup_38S1.mat')
format long g

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
runname=1;
ICAlist=jpmfun_getICAlist(numsubjects,runname);



for s=31:length(subject_list)

cfgjpm.jpmsavename='jpmsave_38subs_MANART';
 cfgjpm.setsavename ='_MANART';

 cfgjpm.art_stepth=100; % 100 for non z
  cfgjpm.art_wmth=100; % 7 z % MOVING WINDOW
 cfgjpm.art_ws=200; % windowsize
  cfgjpm.art_wst=50; % windowstep
 cfgjpm.art_tw=[ 0  8000];
 cfgjpm.art_rate=5;
% 
%   cfgjpm.art_wmth2=8; % 70 for non z % MOVING WINDOW
%  cfgjpm.art_ws2=300; % windowsize
%   cfgjpm.art_wst2=50; % windowstep
%  cfgjpm.art_tw2=[ 0  8000];

if s==9 || s==16 || s==30 || s==31
continue
end

%subjectfolder = [parentfolder subject '\'];
        if s<26
            subject = subject_list{s};
            newsubject = strrep(subject,'-','_');
        else 
            subject = subject_list{s};
            newsubject = subject_list{s};
        end
eeglab
fprintf('\n\n\n*** Processing subject %d(%s) ***\n\n\n', s, subject);
%EEG = pop_loadset('filename',[subject '.set'],'filepath',datafolder);
EEG = pop_loadset('filename',[newsubject '_ICA.set'],'filepath',datafolder);
%EEG = pop_loadset('filename',['tlk4_15_tester_resampfilt.set'],'filepath',datafolder);
EEG = eeg_checkset( EEG );
eeglab redraw
erplab redraw

killICA=(ICAlist(s,:));
disp(killICA);

killICA = nonzeros(killICA)';
EEG = pop_subcomp( EEG, killICA, 0); 
EEG = eeg_checkset( EEG );
eeglab redraw
erplab redraw
  
% Z transform
%{
        tmp = reshape(EEG.data, [size(EEG.data,1) size(EEG.data, 2) * size(EEG.data, 3) ]);
        [jpm.Z,jpm.mu,jpm.sigma] = zscore(tmp, 0, 2);
        tmp = reshape(jpm.Z, size(EEG.data));
        EEG.data = tmp;
        clearvars tmp
%}


[EEG]  = pop_artstep( EEG,'Channel',1:31,'Flag',1,'Threshold', cfgjpm.art_stepth, 'Twindow', cfgjpm.art_tw, 'Windowsize',  cfgjpm.art_ws, 'Windowstep',cfgjpm.art_wst);
[EEG]  = pop_artmwppth( EEG , 'Channel',  1:31, 'Flag', 2, 'Threshold',  cfgjpm.art_wmth, 'Twindow',  cfgjpm.art_tw, 'Windowsize',  cfgjpm.art_ws, 'Windowstep',cfgjpm.art_wst);
[EEG]  = pop_artderiv( EEG , 'Channel',  1:31, 'Flag',  3, 'Rate',  cfgjpm.art_rate, 'Twindow',  cfgjpm.art_tw );
%[EEG]  = pop_artmwppth( EEG , 'Channel',  1:31, 'Flag', 4, 'Threshold',  cfgjpm.art_wmth2, 'Twindow',  cfgjpm.art_tw2, 'Windowsize',  cfgjpm.art_ws2, 'Windowstep',cfgjpm.art_wst2);

% Reverse Z transform
%{
        tmp = reshape(EEG.data, [size(EEG.data, 1) size(EEG.data, 2) * size(EEG.data, 3) ]);
        multy = (tmp.*jpm.sigma)+jpm.mu;
        tmp = reshape(multy, size(EEG.data));
        EEG.data = tmp;
        clearvars tmp
%}
       cfgjpm.reject_auto= EEG.reject.rejmanual;  
       cfgjpm.sumrejauto=sum(cfgjpm.reject_auto);
       cfgjpm.rejautoepochs=find(cfgjpm.reject_auto~=0);
        disp(cfgjpm.sumrejauto);

spec_eegplot(EEG, 80, 3, 'off', []); % (EEG, scale, time, subDC, Pos)
            %spec_eegplot(EEG, 8, 3, 'off', []); % (EEG, scale, time, subDC, Pos)
% figure; pop_eegplot( EEG, 1, 0, 0);
% h=gcf;
% saveas(h,[datafolder sprintf('baller%d.png',s)]); % will create FIG1, FIG2,...
% clearvars h
% close


       cfgjpm.reject_man= EEG.reject.rejmanual;  
       cfgjpm.sumrejman=sum(cfgjpm.reject_man);
       cfgjpm.rejmanepochs=find(cfgjpm.reject_man~=0);
        disp(cfgjpm.sumrejman);


%     jpm.totartperc= length(unique(horzcat(jpm.artstepkill, jpm.artmwppthkill, jpm.artderivkill)))/EEG.trials;
%     jpm.remainingtrials = EEG.trials-length(unique(horzcat(jpm.artstepkill, jpm.artmwppthkill, jpm.artderivkill)));



[ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 2,'savenew',[datafolder  newsubject cfgjpm.setsavename '.set'],'gui','off'); 
EEG = eeg_checkset( EEG );
eeglab redraw
EEG = pop_saveset( EEG, 'filename',[newsubject  cfgjpm.setsavename  '.set'],'filepath',datafolder);
[ALLEEG EEG] = eeg_store(ALLEEG, EEG, CURRENTSET);
clear eeglab



save([datafolder newsubject '_MANART'], 'cfgjpm' );


clearvars cfgjpm ICAkill 
end

%save([datafolder cfgjpm.jpmsavename], 'jpmsave_MANART' );


%% Re-Reference, Epoch, & ICA  remove components 
%{
for s=1:length(subject_list)
% RE-REFERENCE
%{
%NOTE: normalize the data first
chan32 = EEG.data(32,:) ./2;
EEG.data(32,:)  = chan32;
% SIGNAL PROCESSING
    % ch30 = RHE; 31 = RLE; 32 = A2
EEG = pop_reref( EEG, 32); % divide by 2
[ALLEEG, EEG, CURRENTSET] = eeg_store( ALLEEG, EEG, 0 );
EEG = eeg_checkset( EEG );
eeglab redraw 
%}


% ICA 
EEG = pop_runica(EEG, 'icatype', 'runica', 'extended',1,'interrupt','on');
[ALLEEG EEG] = eeg_store(ALLEEG, EEG, CURRENTSET);

[ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 2,'savenew',[datafolder  newsubject '_ICA.set'],'gui','off'); 
EEG = eeg_checkset( EEG );
eeglab redraw
EEG = pop_saveset( EEG, 'filename',[newsubject '_ICA.set'],'filepath',datafolder);
[ALLEEG EEG] = eeg_store(ALLEEG, EEG, CURRENTSET);


%pop_topoplot(EEG, 0, [1:31] ,[newsubject '.set'],[6 6] ,0,'electrodes','on');

%EEG = pop_subcomp( EEG, [1  2  3  8], 0); - tlk4_5


end


%% Automatic artifact flagging












%%

%TRY EPOCHING FIRST
%EEG = pop_epoch( EEG, {'45'}, [-0.5  8], 'newname', [newsubject '_epochs'], 'epochinfo', 'yes');
%[ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 5,'gui','off');

%NOTE: normalize the data first
chan32 = EEG.data(32,:) ./2;
EEG.data(32,:)  = chan32;
% SIGNAL PROCESSING
    % ch30 = RHE; 31 = RLE; 32 = A2
EEG = pop_reref( EEG, 32); % divide by 2
[ALLEEG, EEG, CURRENTSET] = eeg_store( ALLEEG, EEG, 0 );
EEG = eeg_checkset( EEG );
eeglab redraw 

% ICA 
EEG = pop_runica(EEG, 'icatype', 'runica', 'extended',1,'interrupt','on');
[ALLEEG EEG] = eeg_store(ALLEEG, EEG, CURRENTSET);

%pop_topoplot(EEG, 0, [1:31] ,[newsubject '.set'],[6 6] ,0,'electrodes','on');

%EEG = pop_subcomp( EEG, [1  2  3  8], 0); - tlk4_5

[ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 2,'savenew',[datafolder  newsubject '_ICA.set'],'gui','off'); 
EEG = eeg_checkset( EEG );
eeglab redraw
EEG = pop_saveset( EEG, 'filename',[newsubject '_ICA.set'],'filepath',datafolder);
[ALLEEG EEG] = eeg_store(ALLEEG, EEG, CURRENTSET);

jpmsave.(newsubject)=jpm;
clearvars jpm
%end
%}



%}


