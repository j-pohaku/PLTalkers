function [submdls,submdls_smoothed,mdls,mdls_smoothed] = PLTalkers_fwdmodelplot(TRF_study,loadname,pkucfg)


 subnames=fieldnames(TRF_study);
% condnames={'congruent','incongruent'};
condnames=pkucfg.condnames;

%   extrlnames=fieldnames(TRF_study.(subnames{1}).(studynames{1}).(stimnames.audio{1}).(condnames{1}).(extrlnames{1}));

% infonames=fieldnames(TRF_study.(subnames{1}).(condnames{1}).(extrlnames{1}));
% if sum(ismember(infonames,'test'))>0
% testnames=fieldnames(TRF_study.(subnames{1}).(condnames{1}).(extrlnames{1}).test);
% exfmdlname=cellstr((['forwardmodel_' testnames{1}]));
% exfmdlname=strrep(exfmdlname,'_test','');
% else
% exfmdlname=fieldnames(TRF_study.(subnames{1}).(condnames{1}).(extrlnames{1}).forwardmodel); 
% end
% modelnames=fieldnames(TRF_study.(subnames{1}).(condnames{1}).(extrlnames{1}).model)';

 subnames=fieldnames(TRF_study);
    studynames=fieldnames(TRF_study.(subnames{1}));
    studynames(end)=[];
    stims=fieldnames(TRF_study.(subnames{1}).(studynames{1}));
    stimnames.audio=stims(contains(stims,'env'));
    stimnames.video=stims(~contains(stims,'env'));
    clearvars stims
     extrlnames=fieldnames(TRF_study.(subnames{1}).(studynames{1}).(stimnames.audio{1}).(condnames{1}));
    %mdl_blank=TRF_study.(subnames{1}).(studynames{1}).(stimnames.audio{1}).(condnames{1}).(extrlnames{1}).model.(modelnames{1});
    mdl_blank=TRF_study.(subnames{1}).(studynames{1}).(stimnames.audio{1}).(condnames{1}).(extrlnames{1}).forwardmodel;
channames=TRF_study.(subnames{1}).readme.trfchans;
timenames=mdl_blank.t;
%     subnames2=strrep(subnames,loadname,'');
%     subnames2_dropped=subnames2;
%     subnames_dropped=subnames;

% mdl_blank=TRF_study.(subnames{1}).(condnames{1}).(extrlnames{1}).model.(modelnames{1});
% channames=TRF_study.(subnames{1}).readme.trfchans;
% timenames=mdl_blank.t;
%     subnames2=strrep(subnames,loadname,'');
%     subnames2_dropped=subnames2;
%     subnames_dropped=subnames;



% target model size = 1x40x22chans
% USE FOR NORMAL TRF OUTPUTS
clearvars w_hold b_hold w_avg mdlmeds mdlmeans mdls bmdls mdlsubmeans w_hold trlcount w_holdsubmeans w_holdsms w_holdsubmeds bw_holdsubmeds
clearvars bw_hold bw_holdsms bw_holdsubmeans mdls_smoothed bmdls_smoothed submdls_smoothed submdls 
%for m=1:length(modelnames)
    for c=1:length(condnames)
        trlcount=0;
    for s=1:length(subnames)
       % trlcount=trlcount+length(fieldnames(TRF_study.(subnames_dropped{s}).(condnames{c})));
        trlcount=trlcount+length(fieldnames(TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(condnames{c})));
    end
    w_hold.(condnames{c})=zeros(trlcount,size(mdl_blank.w,2),size(mdl_blank.w,3));% 1 40 26
    end
%end
%for m=1:length(modelnames)
    for c=1:length(condnames)
        counter=0;
    for s=1:length(subnames)
            trlnames=fieldnames(TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(condnames{c}));
            for t=1:length(trlnames)
                counter=counter+1;

                if isequal(pkucfg.baseline,'yes')
                   % mytimes= TRF_study.(subnames_dropped{s}).(condnames{c}).(trlnames{t}).forwardmodel.(modelnames{m}).t; 
                    for ch=1:size(TRF_study.(subnames{s}).(condnames{c}).(trlnames{t}).forwardmodel.(modelnames{m}).w,3)
                                        clearvars mybl mywts
                mybl=TRF_study.(subnames{s}).(condnames{c}).(trlnames{t}).model.(modelnames{m}).w(1,1:7,ch);
                mywts=TRF_study.(subnames{s}).(condnames{c}).(trlnames{t}).model.(modelnames{m}).w(1,:,ch)-mean(mybl);
                TRF_study.(subnames{s}).(condnames{c}).(trlnames{t}).model.(modelnames{m}).w(1,:,ch)=mywts;
                    end
                end

         w_hold.(condnames{c})(counter,:,:)=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(condnames{c}).(trlnames{t}).forwardmodel.w; % (bodyparts (8) by time (65)
        % b_hold.(condnames{c})(counter,:)=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(condnames{c}).(trlnames{t}).forwardmodel.b; % (bodyparts (8) by time (65)

         w_holdsms(t,:,:)=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(condnames{c}).(trlnames{t}).forwardmodel.w; % (bodyparts (8) by time (65)
        % b_holdsms(t,:)=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(condnames{c}).(trlnames{t}).forwardmodel.b; % (bodyparts (8) by time (65)

            end
         w_holdsubmeans.(condnames{c})(s,:,:)=mean(w_holdsms,1);
       %  b_holdsubmeans.(condnames{c})(s,:)=mean(b_holdsms,1);

         w_holdsubmeds.(condnames{c})(s,:,:)=median(w_holdsms,1);
       %  b_holdsubmeds.(condnames{c})(s,:)=median(b_holdsms,1);

         clearvars w_holdsms b_holdsms
    end
    end
%end

%w_avg.(condnames{c})(s,:,:)
for c=1:length(condnames)
    mdls.means.(condnames{c})=mdl_blank;
    mdls.meds.(condnames{c})=mdl_blank;
    mdls.means.(condnames{c}).w=mean(w_hold.(condnames{c}),1);
   % mdls.means.(condnames{c}).b=squeeze(mean(b_hold.(condnames{c}),1))';

    mdls.meds.(condnames{c}).w=median(w_hold.(condnames{c}),1);
   % mdls.meds.(condnames{c}).b=squeeze(median(b_hold.(condnames{c}),1))';

    mdls.submeans.(condnames{c})=mdl_blank;
    mdls.submeans.(condnames{c}).w=mean(w_holdsubmeans.(condnames{c}),1);
   % mdls.submeans.(condnames{c}).b=mean(b_holdsubmeans.(condnames{c}),1);

    mdls.submeds.(condnames{c})=mdl_blank;
    mdls.submeds.(condnames{c}).w=median(w_holdsubmeds.(condnames{c}),1);
  %  mdls.submeds.(condnames{c}).b=median(b_holdsubmeds.(condnames{c}),1);

    mdls.submeans4perm.(condnames{c})=mdl_blank;
    mdls.submeans4perm.(condnames{c}).w=w_holdsubmeans.(condnames{c});
   % mdls.submeans4perm.(condnames{c}).b=b_holdsubmeans.(condnames{c});

    mdls.submeds4perm.(condnames{c})=mdl_blank;
    mdls.submeds4perm.(condnames{c}).w=w_holdsubmeds.(condnames{c});
  %  mdls.submeds4perm.(condnames{c}).b=b_holdsubmeds.(condnames{c});

end

% OPTIONAL - smooth weights
mdlfns=fieldnames(mdls);

mdls_smoothed=mdls;
for m=1:length(mdlfns)
for c=1:length(condnames)
    for ch=1:length(channames)
        if m~=5 || m~=6
mdls_smoothed.(mdlfns{m}).(condnames{c}).w(1,:,ch)=smoothdata(mdls.(mdlfns{m}).(condnames{c}).w(1,:,ch));
        else
            for s=1:length(subnames)
            mdls_smoothed.(mdlfns{m}).(condnames{c}).w(s,:,ch)=smoothdata(mdls.(mdlfns{m}).(condnames{c}).w(s,:,ch));
            end
        end
    end
end
end

% plot(mdls.means.(condnames{2}).t,mdls.means.(condnames{2}).w(1,:,13))
% hold on
% plot(mdls.submeans.(condnames{2}).t,mdls.submeans.(condnames{2}).w(1,:,13))
% Size decoder weight matrices to match forward weights
% for m=1:length(mdlfns)
% for c=1:length(condnames)
%     bmdls_smoothed.(mdlfns{m}).(condnames{c}).w=permute(bmdls_smoothed.(mdlfns{m}).(condnames{c}).w,[1 3 2]);
%     bmdls.(mdlfns{m}).(condnames{c}).w=permute(bmdls.(mdlfns{m}).(condnames{c}).w,[1 3 2]);
%     bmdls_smoothed.(mdlfns{m}).(condnames{c}).Dir=1;
%     bmdls.(mdlfns{m}).(condnames{c}).Dir=1;
%     bmdls_smoothed.(mdlfns{m}).(condnames{c}).t=mdls_smoothed.(mdlfns{m}).(condnames{c}).t;
%     bmdls.(mdlfns{m}).(condnames{c}).t=mdls.(mdlfns{m}).(condnames{c}).t;
% end
% end

% make models for each subject
for s=1:length(subnames)
for m=[5 6]   % m=4;
        for c=1:length(condnames)
submdls.(subnames{s}).(condnames{c})=mdls.(mdlfns{m}).(condnames{c});
submdls_smoothed.(subnames{s}).(condnames{c})=mdls_smoothed.(mdlfns{m}).(condnames{c});
submdls.(subnames{s}).(condnames{c}).w=mdls.(mdlfns{m}).(condnames{c}).w(s,:,:);
%submdls.(subnames{s}).(condnames{c}).b=mdls.(mdlfns{m}).(condnames{c}).b(s,:);
submdls_smoothed.(subnames{s}).(condnames{c}).w=mdls_smoothed.(mdlfns{m}).(condnames{c}).w(s,:,:);
% submdls_smoothed.(subnames{s}).(condnames{c}).b=mdls_smoothed.(mdlfns{m}).(condnames{c}).w(s,:);

        end
end
end

%% CHECK MDLS 

% submdls
% submdls_smoothed
% mdls
% mdls_smoothed
% y=2;
% twidx=1:40;
% chanidx=13;

% submdls.(subnamestrim{s}).(condnames{y}).w(1,twidx,chanidx)); % 1x40x22
% submdls_smoothed.(subnamestrim{s}).(condnames{y}).w(1,twidx,chanidx)); % 1x40x22
% mdls.submeans4perm.(condnames{y}).w(s,twidx,chanidx)); % 36x40x22
% mdls_smoothed.submeans4perm.(condnames{y}).w(s,twidx,chanidx)); % 36x40x22
% TRF_GA4perm.(condnames{y}).individual(s,chanidx,twidx));
% TRF_study.(subnames{s}).(condnames{y}).(fnames{t}).model.(modelnames{1}).w(1,twidx,chanidx)));

% check.mdls_smoothedsubmeans=mdls_smoothed.submeans.(condnames{y}).w(1,twidx,chanidx); % 1 40 22
% check.mdls_smoothedsubmeans4perm=mdls_smoothed.submeans4perm.(condnames{y}).w(:,twidx,chanidx); % 36 40 22
% 
% check.mdls_smoothedmeans=mdls_smoothed.means.(condnames{y}).w(1,twidx,chanidx); % 1 40 22
% 
% plot(timenames(twidx),check.mdls_smoothedsubmeans)
% hold on
% plot(timenames(twidx),check.mdls_smoothedmeans)
% hold on
% plot(timenames(twidx),mean(check.mdls_smoothedsubmeans4perm,1))

