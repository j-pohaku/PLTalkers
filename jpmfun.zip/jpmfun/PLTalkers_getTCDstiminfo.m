

function [trfhld,readme] = PLTalkers_getTCDstiminfo(readme,EEG,setupfolder)




%% Actual function
clearvars stiminfomaster

trinityfolder=('C:\Users\jpmomsen\Documents\Research\Projects\Diss_study23\TRF_EEG_analysis\stimdata\psychopystims\vids_trimmp4normvol\');
idxG=dir(trinityfolder);
idxG = idxG(~[idxG.isdir]);
load([setupfolder 'psyPyaudiotrinity.mat']);

load([setupfolder 'trinitystims.mat']);
load([setupfolder 'stims_globmot.mat']);
stiminfomaster.trinitytimeinfo = readtable([setupfolder 'shortlist_AVstimmaster.xlsx'],'Sheet', 'trinity_timeinfo');
stiminfomaster.trinity = readtable([setupfolder 'shortlist_AVstimmaster.xlsx'],'Sheet', 'trinity_allstims');
stiminfomaster.aist = readtable([setupfolder 'shortlist_AVstimmaster.xlsx'],'Sheet', 'aist_allstims');
stiminfomaster.trinitystims =trinitystims;
% load([setupfolder 'aiststims.mat']);
stiminfomaster.trinitystims_globmot =trinity_globmot;

fnames_trinity=fieldnames(trinitystims);
basenames_trinity=strrep(fnames_trinity,'wav_','');
basenames_trinity=strrep(basenames_trinity,'Recording','');
%fnames_aist=fieldnames(aiststims);
gmotnames=fieldnames(stiminfomaster.trinitystims_globmot);
pynames=fieldnames(psyPyaudiotrinity);

clearvars trfhld corefind corestims
trinitycounter=0;

% parfor py=1:length(pynames)
% 
% 
%   [gtspeechenv] = PLTalkers_speechenv(psyPyaudiotrinity.(pynames{py}).wav,psyPyaudiotrinity.(pynames{py}).wavSR,setupfolder,pynames{py});
% 
% 
% end

for i=1:size(readme.subidx,1)
    currstim=readme.subidx{i,2};
    currstim=currstim{1};

    if contains(currstim,'pilot')

        trinitycounter=trinitycounter+1;
        if ~isequal(readme.subidx{i,4}{1},'V')
            %[wav,wavSR]=audioread([idxG(contains({idxG(:).name},currstim)).folder '\' idxG(contains({idxG(:).name},currstim)).name]);
            %[envmTRF,envtime,~] = mTRFenvelope(wav,wavSR,64);
                % envmTRF=psyPyaudiotrinity.(currstim).envmTRF;
                % envtime=psyPyaudiotrinity.(currstim).envtime;  

                [envmTRF,envtime,~] = mTRFenvelope(psyPyaudiotrinity.(currstim).wav,psyPyaudiotrinity.(currstim).wavSR,readme.resamp_sr);

               % [bbwav] = PLTalkers_speechenv(psyPyaudiotrinity.(currstim).wav,psyPyaudiotrinity.(currstim).wavSR);

        else
            %[wav,wavSR]=audioread([idxG(contains({idxG(:).name},strrep(currstim,'V','A'))).folder '\' idxG(contains({idxG(:).name},strrep(currstim,'V','A'))).name]);
            %[envmTRF,envtime,~] = mTRFenvelope(wav,wavSR,64);
               % envmTRF=psyPyaudiotrinity.(strrep(currstim,'V','A')).envmTRF;
               %  envtime=psyPyaudiotrinity.(strrep(currstim,'V','A')).envtime; 

               [envmTRF,envtime,~] = mTRFenvelope(psyPyaudiotrinity.(strrep(currstim,'V','A')).wav,psyPyaudiotrinity.(strrep(currstim,'V','A')).wavSR,readme.resamp_sr); 

               % [bbwav] = PLTalkers_speechenv(psyPyaudiotrinity.(strrep(currstim,'V','A')).wav,psyPyaudiotrinity.(strrep(currstim,'V','A')).wavSR);

        end




        clearvars rawgmot resampgmot rawgmotSR
        rawgmot=stiminfomaster.trinitystims_globmot.(strrep(currstim,'pilot_','')).pixelChangesmoothed;
        rawgmotSR=stiminfomaster.trinitystims_globmot.(strrep(currstim,'pilot_','')).FrameRate;
        resampgmot=mTRFenvelope(rawgmot,rawgmotSR,readme.resamp_sr);

        currstim2=strrep(currstim,'pilot_','');
        currstim2=strrep(currstim2,'A','');
        currstim2=strrep(currstim2,'V','');
        currstim2=strrep(currstim2,'I','');

        trfhld.trinity.audio.env1{trinitycounter,1}=trinitystims.(fnames_trinity{contains(basenames_trinity,currstim2)}).env1;
        trfhld.trinity.audio.env1{trinitycounter,2}=currstim;
        trfhld.trinity.audio.env1{trinitycounter,3}=currstim2;
        trfhld.trinity.audio.envmTRF{trinitycounter,1}=trinitystims.(fnames_trinity{contains(basenames_trinity,currstim2)}).envmTRF;
        trfhld.trinity.audio.envmTRF{trinitycounter,2}=currstim;
        trfhld.trinity.audio.envmTRF{trinitycounter,3}=currstim2;

        trfhld.trinity.bmot.globmot{trinitycounter,1}=resampgmot;
        trfhld.trinity.bmot.globmot{trinitycounter,2}=currstim;
        trfhld.trinity.bmot.globmot{trinitycounter,3}=currstim2;

        %  subplot(2,1,1)
        %  plot(mean(envmTRF,2))
        %  subplot(2,1,2)
        %  plot(trfhld.trinity.audio.envmTRF{trinitycounter,1})

        clearvars photo_idx   vonset_idx vonset_ms   voffset_ms voffset_idx
        photo_idx=readme.vidonset;
        vonset_idx=find(EEG.times==0);
        vonset_ms=EEG.epoch(i).eventlatency{cell2mat(EEG.epoch(i).eventtype)>300};
        if sum(ismember(cell2mat(EEG.epoch(i).eventtype),41))==0
            voffset_ms=EEG.times(end);
        else
            voffset_ms=EEG.epoch(i).eventlatency{find(cell2mat(EEG.epoch(i).eventtype)==41)}; % vid offset ms
        end
        [~,voffset_idx]=min(abs(EEG.times-voffset_ms));

        readme.behdta.bdfinfo.videocodeidxs{trinitycounter,1}=vonset_idx:voffset_idx; % 1217 total

        % USE PSYCHOPYSTIM INSTEAD
        if isequal(readme.stim2use,'new')
            trfhld.trinity.audio.envmTRF{trinitycounter,1}=mean(envmTRF,2);
           %trfhld.trinity.audio.envmTRF{trinitycounter,1}=bbwav;
        end

        % length(envmTRF) TARGET SAMPLES TAKEN FROM EEG
        if isequal(readme.alignment,'photo')
            % OPTION 1 - ALIGN TO PHOTOONSET
            trfhld.trinity.eeg{trinitycounter,1}=EEG.data(:,photo_idx:photo_idx+(length(trfhld.trinity.audio.envmTRF{trinitycounter,1})-1),i)';
        else
            % OPTION 2 - ALIGN TO END OF VIDEO BASED ON OFFSET CODE
            trfhld.trinity.eeg{trinitycounter,1}=EEG.data(:,voffset_idx-(length(trfhld.trinity.audio.envmTRF{trinitycounter,1})-1):voffset_idx,i)';
        end
        % OPTION 3 - CENTER EEG

        if isequal(readme.croptrials,'yes')
            cropper=readme.cropsamples;
            cropper2=cropper-1;
            trfhld.trinity.audio.envmTRF{trinitycounter,1}(1:cropper,:)=[];
            trfhld.trinity.bmot.globmot{trinitycounter,1}(1:cropper,:)=[];
            trfhld.trinity.eeg{trinitycounter,1}(1:cropper,:)=[];
            trfhld.trinity.audio.envmTRF{trinitycounter,1}(end-cropper2:end,:)=[];
            trfhld.trinity.eeg{trinitycounter,1}(end-cropper2:end,:)=[];
            trfhld.trinity.bmot.globmot{trinitycounter,1}(end-cropper2:end,:)=[];
        end
        %if readme.photoonsetms(i,2)>10 || readme.photoonsetms(i,2)<0
        %trfhld.trinity.eeg{trinitycounter,1}=EEG.data(:,vonset:vonset+length(trfhld.trinity.audio.envmTRF{trinitycounter,1}),i)'; %size = 26        1344         181
        %trfhld.trinity.eeg{trinitycounter,1}=EEG.data(:,vonset:voffset,i)'; %size = 26        1344         181
        trfhld.trinity.eegtrial{trinitycounter,1}=readme.subidx{i,8};
        trfhld.trinity.eegvonset{trinitycounter,1}=photo_idx;
        trfhld.trinity.eegvoffset{trinitycounter,1}=voffset_idx;

%         trfhld.trinity.biomot.potenergy{trinitycounter,1}=trinitystims.(fnames_trinity{find(contains(basenames_trinity,currstim))}).mocap.demppotsum;
%         trfhld.trinity.biomot.grf{trinitycounter,1}=trinitystims.(fnames_trinity{find(contains(basenames_trinity,currstim))}).mocap.demppotsumdv;
%         trfhld.trinity.biomot.rotenergy{trinitycounter,1}=trinitystims.(fnames_trinity{find(contains(basenames_trinity,currstim))}).mocap.demprotsum;
%         trfhld.trinity.biomot.rotdv{trinitycounter,1}=trinitystims.(fnames_trinity{find(contains(basenames_trinity,currstim))}).mocap.demprotsumdv;
%         trfhld.trinity.biomot.transenergy{trinitycounter,1}=trinitystims.(fnames_trinity{find(contains(basenames_trinity,currstim))}).mocap.demptranssum;
%         trfhld.trinity.biomot.transdv{trinitycounter,1}=trinitystims.(fnames_trinity{find(contains(basenames_trinity,currstim))}).mocap.demptranssumdv;
%         trfhld.trinity.biomot.Xpos1{trinitycounter,1}=trinitystims.(fnames_trinity{find(contains(basenames_trinity,currstim))}).mocap.dempXpos1;
%         trfhld.trinity.biomot.Ypos2{trinitycounter,1}=trinitystims.(fnames_trinity{find(contains(basenames_trinity,currstim))}).mocap.dempYpos2;
%         trfhld.trinity.biomot.Zpos3{trinitycounter,1}=trinitystims.(fnames_trinity{find(contains(basenames_trinity,currstim))}).mocap.dempZpos3;
%         trfhld.trinity.biomot.Xvel1{trinitycounter,1}=trinitystims.(fnames_trinity{find(contains(basenames_trinity,currstim))}).mocap.dempXvel1;
%         trfhld.trinity.biomot.Yvel2{trinitycounter,1}=trinitystims.(fnames_trinity{find(contains(basenames_trinity,currstim))}).mocap.dempYvel2;
%         trfhld.trinity.biomot.Zvel3{trinitycounter,1}=trinitystims.(fnames_trinity{find(contains(basenames_trinity,currstim))}).mocap.dempZvel3;
%         trfhld.trinity.biomot.Xaccel{trinitycounter,1}=trinitystims.(fnames_trinity{find(contains(basenames_trinity,currstim))}).mocap.dempXaccel1;
%         trfhld.trinity.biomot.Yaccel2{trinitycounter,1}=trinitystims.(fnames_trinity{find(contains(basenames_trinity,currstim))}).mocap.dempYaccel2;
%         trfhld.trinity.biomot.Zaccel3{trinitycounter,1}=trinitystims.(fnames_trinity{find(contains(basenames_trinity,currstim))}).mocap.dempZaccel3;

        readme.stimandeeglength(i,1)=length(trfhld.trinity.audio.env1{trinitycounter,1});
        readme.stimandeeglength(i,2)=length(trfhld.trinity.eeg{trinitycounter,1});
    else
        continue
    end
end




% create better organization for stim and resp data
% sum(readme.stimandeeglength(:,1)~=0);
% corestims=unique(trfhld.trinity.audio.envmTRF(:,3));
% condnames={'A','V','AV','AVI'};
% for t=1:length(condnames)
%     corestimresp.(condnames{c})(:,3)=condnames;
% end



% Normalize stimulus info
if isequal( readme.normstim,'yes')
    %corestims=unique(trfhld.trinity.audio.envmTRF(:,3));
%     contains(trfhld.trinity.audio.envmTRF(:,2),'_V_');
%     contains(trfhld.trinity.audio.envmTRF(:,2),'_A_');
%     contains(trfhld.trinity.audio.envmTRF(:,2),'_AV_');
% std(vertcat(trfhld.trinity.audio.envmTRF{contains(trfhld.trinity.audio.envmTRF(:,2),'_AV_'),1}))
% std(vertcat(trfhld.trinity.audio.envmTRF{contains(trfhld.trinity.audio.envmTRF(:,2),'_AVI_'),1}))
% std(vertcat(trfhld.trinity.audio.envmTRF{contains(trfhld.trinity.audio.envmTRF(:,2),'_A_'),1}))
% std(vertcat(trfhld.trinity.audio.envmTRF{contains(trfhld.trinity.audio.envmTRF(:,2),'_V_'),1}))
    clearvars  fnstrinity
    % fns3 = fieldnames(trfhld.trinity.audio);
    % fnstrinity =vertcat(fns4);
    clearvars fns1 fns2 fns3 fns4 currstim
    for i=1:size(trfhld.trinity.audio.envmTRF(:,3),1)
            trfhld.trinity.audio.env1{i,1}= trfhld.trinity.audio.env1{i,1}/std(vertcat(trfhld.trinity.audio.env1{:,1}));
            trfhld.trinity.audio.envmTRF{i,1}=trfhld.trinity.audio.envmTRF{i,1}/std(vertcat(trfhld.trinity.audio.envmTRF{:,1}));
            trfhld.trinity.bmot.globmot{i,1}=trfhld.trinity.bmot.globmot{i,1}/std(vertcat(trfhld.trinity.bmot.globmot{:,1}));
    end
end


%corestims=unique(trfhld.trinity.audio.envmTRF(:,3));


if sum(contains(readme.trfnames_trinity,'globmot'))>0
        % Loop to make all stim resp same sample length
        for i=1:length(trfhld.trinity.audio.envmTRF(:,3))
            corefind=find(ismember(trfhld.trinity.audio.envmTRF(:,3),trfhld.trinity.audio.envmTRF{i,3}));
            clearvars lengholdA lengholdV lenghold lengholdE minnum
            for cf=1:length(corefind)
                lengholdA(cf)=length(trfhld.trinity.audio.envmTRF{corefind(cf),1});
                lengholdV(cf)=length(trfhld.trinity.bmot.globmot{corefind(cf),1});
                lengholdE(cf)=length(trfhld.trinity.eeg{corefind(cf),1});
            end
        lenghold=[lengholdE ;lengholdA ;lengholdV];
        [minnum,~]=min(lenghold,[],'all');
        if sum(lenghold(:)==minnum)~=12
            for ii=1:length(corefind)
                if lengholdE(ii)~=minnum
                    while length(trfhld.trinity.eeg{corefind(ii),1})~=minnum
                        trfhld.trinity.eeg{corefind(ii),1}(end,:)=[];
                    end
                end
                if lengholdA(ii)~=minnum
                    while length(trfhld.trinity.audio.envmTRF{corefind(ii),1})~=minnum
                        trfhld.trinity.audio.envmTRF{corefind(ii),1}(end,:)=[];
                    end
                end
                if lengholdV(ii)~=minnum
                    while length(trfhld.trinity.bmot.globmot{corefind(ii),1})~=minnum
                        trfhld.trinity.bmot.globmot{corefind(ii),1}(end,:)=[];
                    end
                end
            end
        end
        end

else
% Loop to make all stim resp same sample length
        for i=1:length(trfhld.trinity.audio.envmTRF(:,3))
            corefind=find(ismember(trfhld.trinity.audio.envmTRF(:,3),trfhld.trinity.audio.envmTRF{i,3}));
            clearvars lengholdA lenghold lengholdE minnum
            for cf=1:length(corefind)
                lengholdA(cf)=length(trfhld.trinity.audio.envmTRF{corefind(cf),1});
                lengholdE(cf)=length(trfhld.trinity.eeg{corefind(cf),1});
            end
        lenghold=[lengholdE ;lengholdA ];
        [minnum,~]=min(lenghold,[],'all');
        if sum(lenghold(:)==minnum)~=8
            for ii=1:length(corefind)
                if lengholdE(ii)~=minnum
                    while length(trfhld.trinity.eeg{corefind(ii),1})~=minnum
                        trfhld.trinity.eeg{corefind(ii),1}(end,:)=[];
                    end
                end
                if lengholdA(ii)~=minnum
                    while length(trfhld.trinity.audio.envmTRF{corefind(ii),1})~=minnum
                        trfhld.trinity.audio.envmTRF{corefind(ii),1}(end,:)=[];
                    end
                end
            end
        end
        end
end




% 
% corestims=unique(trfhld.trinity.audio.envmTRF(:,3));
% 
% for i=1:length(corestims)%(trfhld.trinity.audio.envmTRF,1)
% corefind=find(ismember(trfhld.trinity.audio.envmTRF(:,3),corestims{i}));
% trfhld.trinity.core_env_gmot_eeg.(['stim' corestims{i}])=trfhld.trinity.audio.envmTRF(corefind,2);
% trfhld.trinity.core_env_gmot_eeg.(['stim' corestims{i}])(:,2)=trfhld.trinity.audio.envmTRF(corefind,1);
% trfhld.trinity.core_env_gmot_eeg.(['stim' corestims{i}])(:,3)=trfhld.trinity.bmot.gmot(corefind,1);
% trfhld.trinity.core_env_gmot_eeg.(['stim' corestims{i}])(:,4)=trfhld.trinity.eeg(corefind,1);
% clearvars lenghold minidx
% for ii=1:size(trfhld.trinity.core_env_gmot_eeg.(['stim' corestims{i}]),1)
% lenghold(ii)=length(trfhld.trinity.core_env_gmot_eeg.(['stim' corestims{i}]){ii,2});
% end
% [~,minidx]= min(lenghold);
% for ii=1:size(trfhld.trinity.core_env_gmot_eeg.(['stim' corestims{i}]),1)
%     if ii==minidx
%         continue
%     else
% while length(trfhld.trinity.audio.envmTRF{corefind(ii),1})~=lenghold(minidx)
%         trfhld.trinity.audio.envmTRF{corefind(ii),1}(end)=[];
%         trfhld.trinity.bmot.gmot{corefind(ii),1}(end)=[];
%         trfhld.trinity.eeg{corefind(ii),1}(end,:)=[];
%         trfhld.trinity.core_env_gmot_eeg.(['stim' corestims{i}]){ii,2}(end)=[];
%         trfhld.trinity.core_env_gmot_eeg.(['stim' corestims{i}]){ii,3}(end)=[];
%         trfhld.trinity.core_env_gmot_eeg.(['stim' corestims{i}]){ii,4}(end,:)=[];
% end
%     end
% end
% 
% 
% end




% Loop to make all stim resp same sample length
% clearvars tottrlsize
% tottrlsize=size(strain.(condnames{c}).(audiostims{1}),1);
% for stt=1:length(audiostims) % stim type
%     %for c=1:length(condnames)
%         for t=1:size(strain.(condnames{c}).(audiostims{stt}),1)   %size(trflooper.(loopernames{d}).(condnames{c}),1) % t = num trials in multitrain loop
%  [~,minidx]= min([size(strain.(condnames{1}).(audiostims{stt}){t},1) size(rtrain.(condnames{1}){t},1) size(rtrain.(condnames{2}){t},1) size(rtrain.(condnames{3}){t},1) size(rtrain.(condnames{4}){t},1) ]);
% if minidx==1
%     for c=1:length(condnames)
%         for ii=1:abs(size(strain.(condnames{1}).(audiostims{stt}){t},1)-size(rtrain.(condnames{c}){t},1))
%                 rtrain.(condnames{c}){t}(end,:)=[];
%         end
%     end
% end
% 
% if minidx==2
%         for ii=1:abs(size(strain.(condnames{1}).(audiostims{stt}){t},1)-size(rtrain.(condnames{1}){t},1))
%                 strain.(condnames{1}).(audiostims{stt}){t}(end,:)=[];
%         end
%     for c=1:length(condnames)
%         if c==1
%             continue
%         end
%         for ii=1:abs(size(rtrain.(condnames{1}){t},1)-size(rtrain.(condnames{c}){t},1))
%                 rtrain.(condnames{c}){t}(end,:)=[];
%         end
%     end
% end
% 
% if minidx==3
%         for ii=1:abs(size(strain.(condnames{1}).(audiostims{stt}){t},1)-size(rtrain.(condnames{2}){t},1))
%                 strain.(condnames{1}).(audiostims{stt}){t}(end,:)=[];
%         end
%     for c=1:length(condnames)
%         if c==2
%             continue
%         end
%         for ii=1:abs(size(rtrain.(condnames{2}){t},1)-size(rtrain.(condnames{c}){t},1))
%                 rtrain.(condnames{c}){t}(end,:)=[];
%         end
%     end
% 
% end
% if minidx==4
%         for ii=1:abs(size(strain.(condnames{1}).(audiostims{stt}){t},1)-size(rtrain.(condnames{3}){t},1))
%                 strain.(condnames{1}).(audiostims{stt}){t}(end,:)=[];
%         end
%     for c=1:length(condnames)
%         if c==3
%             continue
%         end
%         for ii=1:abs(size(rtrain.(condnames{3}){t},1)-size(rtrain.(condnames{c}){t},1))
%                 rtrain.(condnames{c}){t}(end,:)=[];
%         end
%     end
% end
% if minidx==5
%         for ii=1:abs(size(strain.(condnames{1}).(audiostims{stt}){t},1)-size(rtrain.(condnames{4}){t},1))
%                 strain.(condnames{1}).(audiostims{stt}){t}(end,:)=[];
%         end
%     for c=1:length(condnames)
%         if c==4
%             continue
%         end
%         for ii=1:abs(size(rtrain.(condnames{4}){t},1)-size(rtrain.(condnames{c}){t},1))
%                 rtrain.(condnames{c}){t}(end,:)=[];
%         end
%     end
% 
% end
% 
%         end
% end






