function     TRF_study = PLTalkers_makeadditive_sublambda(pkucfg,TRF_study)


% pkucfg=[];
% pkucfg.modeltype='backward';
% pkucfg.runpredtest='yes';
% pkucfg.Dir = -1; % direction of causality
% pkucfg.tmin = -100; % minimum time lag (ms)
% pkucfg.tmax = 500; % maximum time lag (ms)
% pkucfg.fs=128;
% pkucfg.lambda = 10.^(-24:2:24); % regularization parameters (ridge values?)
% pkucfg.zeropad=0;
% pkucfg.unimodels={'A','V'};
% pkucfg.newmdlname={'ApV'};
% pkucfg.newmdlcompare={'AVC'};
% pkucfg.conds2pred={'ApV','AVC','AVI','A','V'};
% pkucfg.cond2pullstim={'AVC','AVC','AVI','A','V'};
% TRF_study = PLTalkers_makeadditiveFIXED(pkucfg,TRF_study);clc;


subnames=fieldnames(TRF_study);
studynames=fieldnames(TRF_study.(subnames{1}));
studynames(end)=[];
stims=fieldnames(TRF_study.(subnames{1}).(studynames{1}));
stimnames.audio=stims(contains(stims,'env'));
stimnames.video=stims(~contains(stims,'env'));
clearvars stims
Dir=pkucfg.Dir;
tmin=pkucfg.tmin;
tmax=pkucfg.tmax;
fs=pkucfg.fs;
lambda=pkucfg.lambda;
zeropad=pkucfg.zeropad;



% Make additive model    TRF_study.TCD_sub002.trinity.envmTRF.Atrls.test{1, 1}.r

for s=1:length(subnames)
    trlnum=length(TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.unimodels{1}).forwardmodel);
    strain1=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.unimodels{1}).strain;
    rtrain1=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.unimodels{1}).rtrain;
    stest1=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.unimodels{1}).stest;
    rtest1=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.unimodels{1}).rtest;
    strain2=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.unimodels{2}).strain;
    rtrain2=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.unimodels{2}).rtrain;
    stest2=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.unimodels{2}).stest;
    rtest2=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.unimodels{2}).rtest;
    strain1=vertcat(stest1{1},strain1{1});
    rtrain1=vertcat(rtest1{1},rtrain1{1});
    strain2=vertcat(stest2{1},strain2{1});
    rtrain2=vertcat(rtest2{1},rtrain2{1});

    strain3=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlcompare{1}).strain;
    rtrain3=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlcompare{1}).rtrain;
    stest3=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlcompare{1}).stest;
    rtest3=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlcompare{1}).rtest;
    strain3=vertcat(stest3{1},strain3{1});
    rtrain3=vertcat(rtest3{1},rtrain3{1});

      model1 = mTRFtrain(strain1,rtrain1,fs,Dir,tmin,tmax,TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.unimodels{1}).lambdause,'zeropad',zeropad);
      model2 = mTRFtrain(strain2,rtrain2,fs,Dir,tmin,tmax,TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.unimodels{2}).lambdause,'zeropad',zeropad);

    ApVmodel=model1;
    ApVmodel.w=model1.w+model2.w;
    ApVmodel.b=(model1.b+model2.b)/2;
    TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlname{1}).decmodelall=ApVmodel;

    clearvars FApVmodelplot Fmodelplot2 Fmodelplot1
    lambda1=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.unimodels{1}).lambdause;
    lambda2=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.unimodels{2}).lambdause;

    %lambda2=lambda(maxloc1);

    Fmodelplot1 = mTRFtrain(strain1,rtrain1,fs,1,tmin,tmax,lambda1,'zeropad',zeropad);
    Fmodelplot2 = mTRFtrain(strain2,rtrain2,fs,1,tmin,tmax,lambda2,'zeropad',zeropad);
    FApVmodelplot=Fmodelplot1;
    FApVmodelplot.w=Fmodelplot1.w+Fmodelplot2.w;
    FApVmodelplot.b=(Fmodelplot1.b+Fmodelplot2.b)/2;
    TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlname{1}).forwardmodelplot =FApVmodelplot;

    clearvars model1 model2 model1p2 pred test Fmodel1p2 Fmodel1 Fmodel2 
    clearvars strain_cond1 strain_cond2 rtrain_cond1 rtrain_cond2 stest_cond3 rtest_cond3
    parfor t=1:trlnum % t = num trials in multitrain loop
        strain_cond1{t}=strain1;
        strain_cond2{t}=strain2;
        rtrain_cond1{t}=rtrain1;
        rtrain_cond2{t}=rtrain2;

        strain_cond1{t}(t)=[];
        strain_cond2{t}(t)=[];
        rtrain_cond1{t}(t)=[];
        rtrain_cond2{t}(t)=[];

        stest_cond3{t}=stest3{t};
        rtest_cond3{t}=rtest3{t};
        model1p2{t}=[]
        model1{t}=[];
        model2{t}=[];
        pred{t}=[];
        test{t}=[];
        Fmodel1p2{t}=[]
        Fmodel1{t}=[];
        Fmodel2{t}=[];

    end




    parfor t=1:trlnum
        model1{t} = mTRFtrain(strain_cond1{t},rtrain_cond1{t},fs,Dir,tmin,tmax,lambda1,'zeropad',zeropad);
        model2{t} = mTRFtrain(strain_cond2{t},rtrain_cond2{t},fs,Dir,tmin,tmax,lambda2,'zeropad',zeropad);
        model1p2{t}=model1{t};
        model1p2{t}.w=model1{t}.w+model2{t}.w;
        model1p2{t}.b=(model1{t}.b+model2{t}.b)/2;
        [pred{t},test{t}]=mTRFpredict(stest_cond3{t},rtest_cond3{t},model1p2{t},'zeropad',zeropad);

        % make below same as above but for forward model
        Fmodel1{t} = mTRFtrain(strain_cond1{t},rtrain_cond1{t},fs,1,tmin,tmax,lambda1,'zeropad',zeropad);
        Fmodel2{t} = mTRFtrain(strain_cond2{t},rtrain_cond2{t},fs,1,tmin,tmax,lambda2,'zeropad',zeropad);
        Fmodel1p2{t}=Fmodel1{t};
        Fmodel1p2{t}.w=Fmodel1{t}.w+Fmodel2{t}.w;
        Fmodel1p2{t}.b=(Fmodel1{t}.b+Fmodel2{t}.b)/2;
    end
    TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlname{1}).model=model1p2;
    TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlname{1}).forwardmodel=Fmodel1p2;
    TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlname{1}).pred=pred;
    TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlname{1}).test=test;
    TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlname{1}).stest=stest3;
    TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlname{1}).rtest=rtest3;
    TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlname{1}).cvidxA=lambda1;
    TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlname{1}).cvidxV=lambda2;
    TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlname{1}).coderan='PLTalkers_makeadditive_sublambda';

end



%     for t=1:trlnum
%
% meanavc(t)=TRF_study.TCD_sub001.trinity.envmTRF.AVC.test{t}.r;
% meanh(t)=TRF_study.TCD_sub001.trinity.envmTRF.ApV.test{t}.r;
%
%     end



%
%
% for t=1:trlnum
%
%     cv{t} = mTRFcrossval(strain_Atrls{t},rtrain_Atrls{t},fs,Dir,tmin,tmax,lambda,'zeropad',zeropad,'fast',1);
%     [rmax{t},idx{t}] = max(mean(cv{t}.r,1));
%     model{t} = mTRFtrain(strain_Atrls{t},rtrain_Atrls{t},fs,Dir,tmin,tmax,lambda(idx{t}),'zeropad',zeropad);
%     [pred{t},test{t}]=mTRFpredict(stest_Atrls{t},rtest_Atrls{t},model{t},'zeropad',zeropad);
%     forwardmodel{t} = mTRFtransform(model{t},rtrain_Atrls{t});
%
%
%
%
%     m1=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.unimodels{1}).model{1,t};
%     m2=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.unimodels{2}).model{1,t};
%     fm1=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.unimodels{1}).forwardmodel{1,t};
%     fm2=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.unimodels{2}).forwardmodel{1,t};
%     stest=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlcompare{1}).stest{1,t};
%     rtest=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlcompare{1}).rtest{1,t};
%     %natrating=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlcompare{1}).(trlnames{t}).natrating;
%     if isequal(pkucfg.modeltype,'backward')
%         nm=m1;
%         nm.b1=m1.b;
%         nm.b2=m2.b;
%         nm.b=(nm.b1+nm.b2)/2;
%         nm.w=m1.w+m2.w;
%     else
%         nm=[];
%     end
%     nfm=fm1;
%     nfm.w=fm1.w+fm2.w;
%     TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlname{1}).forwardmodel{1,t}=nfm;
%     TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlname{1}).model{1,t}=nm;
%     TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlname{1}).stest{1,t}=stest;
%     TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlname{1}).rtest{1,t}=rtest;
%
%     %TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlname{1}).(trlnames{t}).natrating{1,t}=natrating;
% end
% TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlname{1}).stimnames=    TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlcompare{1}).stimnames;
%
% end
%
%
% if isequal(pkucfg.runpredtest,'yes')
%
%     % Run model testing
%     for s=1:length(subnames)
%         for c=1:length(pkucfg.conds2pred)
%             trlnames=length(TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.unimodels{1}).test);
%             for t=1:trlnames
%                 stest=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.cond2pullstim{c}).stest{1,t};
%                 nm=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.conds2pred{c}).model{1,t};
%                 rtest= TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.conds2pred{c}).rtest{1,t}; %.(pkucfg.testeeg);
%                 %natrating=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.conds2pred{c}).(trlnames{t}).natrating;
%                 [pred,test]=mTRFpredict(stest,rtest,nm,'zeropad',pkucfg.zeropad);
%
%                 TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.conds2pred{c}).pred{1,t}=pred;
%                 TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.conds2pred{c}).test{1,t}=test;
%                 TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.conds2pred{c}).stest{1,t}=stest;
%                 TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.conds2pred{c}).rtest{1,t}=rtest;
%                 % TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.conds2pred{c}).natrating=natrating;
%
%
%             end
%
%         end
%     end
%
% end