function     TRF_study = PLTalkers_makeadditive_sublambda_byfreq(pkucfg,TRF_study)



subnames=fieldnames(TRF_study);
studynames=fieldnames(TRF_study.(subnames{1}));
studynames(end)=[];
stims=fieldnames(TRF_study.(subnames{1}).(studynames{1}));
stimnames.audio=stims(contains(stims,'env'));
stimnames.video=stims(~contains(stims,'env'));
clearvars stims
Dir=pkucfg.Dir;
tmin=pkucfg.tmin;
tmax=pkucfg.tmax;
fs=pkucfg.fs;
lambda=pkucfg.lambda;
zeropad=pkucfg.zeropad;
for bp=pkucfg.freqs

freqnames{bp,1}=['Fq_' num2str(bp)];
end

% In fq
        % model: {1×32 cell}
        %                 pred: {1×32 cell}
        %                 test: {1×32 cell}
        %         forwardmodel: {1×32 cell}
        %     forwardmodelplot: [1×1 struct]
        %                rtest: {1×32 cell}

% under condname
          % cv: [1×1 struct]
          %               rmax: [1×1 struct]
          %                idx: [1×1 struct]
          %          lambdause: 1
          %               Fq_1: [1×1 struct]
          %              stest: {1×32 cell}
          %          stimnames: {32×1 cell}
          %   originalepochnum: {32×1 cell}
          %           rndperms: []

for bp=pkucfg.freqs
% Make additive model    TRF_study.TCD_sub002.trinity.envmTRF.Atrls.test{1, 1}.r

for s=1:length(subnames)
    trlnum=length(TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.unimodels{1}).stimnames);

    stest1=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.unimodels{1}).stest;
    rtest1=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.unimodels{1}).(freqnames{bp}).rtest;
    stest2=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.unimodels{2}).stest;
    rtest2=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.unimodels{2}).(freqnames{bp}).rtest;

    stest3=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlcompare{1}).stest;
    rtest3=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlcompare{1}).(freqnames{bp}).rtest;
 

        clearvars rtrain1 rtrain2 strain1 strain2
        parfor t=1:trlnum
            strain1{t,1}=stest1(:);strain1{t,1}(t)=[];
            rtrain1{t,1}=rtest1(:);rtrain1{t,1}(t)=[];
            strain2{t,1}=stest2(:);strain2{t,1}(t)=[];
            rtrain2{t,1}=rtest2(:);rtrain2{t,1}(t)=[];
        end
   
    strain1=vertcat(stest1{1},strain1{1});
    rtrain1=vertcat(rtest1{1},rtrain1{1});
    strain2=vertcat(stest2{1},strain2{1});
    rtrain2=vertcat(rtest2{1},rtrain2{1});
    % strain3=vertcat(stest3{1},strain3{1});
    % rtrain3=vertcat(rtest3{1},rtrain3{1});
    % 
    model1 = mTRFtrain(strain1,rtrain1,fs,Dir,tmin,tmax,TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.unimodels{1}).lambdause,'zeropad',zeropad);
    model2 = mTRFtrain(strain2,rtrain2,fs,Dir,tmin,tmax,TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.unimodels{2}).lambdause,'zeropad',zeropad);

    ApVmodel=model1;
    ApVmodel.w=model1.w+model2.w;
    ApVmodel.b=(model1.b+model2.b)/2;
    TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlname{1}).decmodelall=ApVmodel;

    clearvars FApVmodelplot Fmodelplot2 Fmodelplot1
    lambda1=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.unimodels{1}).lambdause;
    lambda2=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.unimodels{2}).lambdause;

    %lambda2=lambda(maxloc1);

    Fmodelplot1 = mTRFtrain(strain1,rtrain1,fs,1,tmin,tmax,lambda1,'zeropad',zeropad);
    Fmodelplot2 = mTRFtrain(strain2,rtrain2,fs,1,tmin,tmax,lambda2,'zeropad',zeropad);
    FApVmodelplot=Fmodelplot1;
    FApVmodelplot.w=Fmodelplot1.w+Fmodelplot2.w;
    FApVmodelplot.b=(Fmodelplot1.b+Fmodelplot2.b)/2;
    TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlname{1}).forwardmodelplot =FApVmodelplot;

    clearvars model1 model2 model1p2 pred test Fmodel1p2 Fmodel1 Fmodel2 
    clearvars strain_cond1 strain_cond2 rtrain_cond1 rtrain_cond2 stest_cond3 rtest_cond3
    parfor t=1:trlnum % t = num trials in multitrain loop
        strain_cond1{t}=strain1;
        strain_cond2{t}=strain2;
        rtrain_cond1{t}=rtrain1;
        rtrain_cond2{t}=rtrain2;

        strain_cond1{t}(t)=[];
        strain_cond2{t}(t)=[];
        rtrain_cond1{t}(t)=[];
        rtrain_cond2{t}(t)=[];

        stest_cond3{t}=stest3{t};
        rtest_cond3{t}=rtest3{t};
        model1p2{t}=[]
        model1{t}=[];
        model2{t}=[];
        pred{t}=[];
        test{t}=[];
        Fmodel1p2{t}=[]
        Fmodel1{t}=[];
        Fmodel2{t}=[];

    end




    parfor t=1:trlnum
        model1{t} = mTRFtrain(strain_cond1{t},rtrain_cond1{t},fs,Dir,tmin,tmax,lambda1,'zeropad',zeropad);
        model2{t} = mTRFtrain(strain_cond2{t},rtrain_cond2{t},fs,Dir,tmin,tmax,lambda2,'zeropad',zeropad);
        model1p2{t}=model1{t};
        model1p2{t}.w=model1{t}.w+model2{t}.w;
        model1p2{t}.b=(model1{t}.b+model2{t}.b)/2;
        [pred{t},test{t}]=mTRFpredict(stest_cond3{t},rtest_cond3{t},model1p2{t},'zeropad',zeropad);

        % make below same as above but for forward model
        Fmodel1{t} = mTRFtrain(strain_cond1{t},rtrain_cond1{t},fs,1,tmin,tmax,lambda1,'zeropad',zeropad);
        Fmodel2{t} = mTRFtrain(strain_cond2{t},rtrain_cond2{t},fs,1,tmin,tmax,lambda2,'zeropad',zeropad);
        Fmodel1p2{t}=Fmodel1{t};
        Fmodel1p2{t}.w=Fmodel1{t}.w+Fmodel2{t}.w;
        Fmodel1p2{t}.b=(Fmodel1{t}.b+Fmodel2{t}.b)/2;
    end
      % model: {1×32 cell}
        %                 pred: {1×32 cell}
        %                 test: {1×32 cell}
        %         forwardmodel: {1×32 cell}
        %     forwardmodelplot: [1×1 struct]
        %                rtest: {1×32 cell}
    TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlname{1}).(freqnames{bp}).model=model1p2;
    TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlname{1}).(freqnames{bp}).forwardmodel=Fmodel1p2;
    TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlname{1}).(freqnames{bp}).pred=pred;
    TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlname{1}).(freqnames{bp}).test=test;
     TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlname{1}).stimnames=TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.unimodels{1}).stimnames;
    % TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlname{1}).stest=stest3;
    % TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlname{1}).rtest=rtest3;
    TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlname{1}).cvidxA=lambda1;
    TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlname{1}).cvidxV=lambda2;
    TRF_study.(subnames{s}).(studynames{1}).(stimnames.audio{1}).(pkucfg.newmdlname{1}).coderan='PLTalkers_makeadditive_sublambda_byfreq';

end

end % end freq loop 
 