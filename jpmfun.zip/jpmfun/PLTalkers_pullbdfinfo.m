
% Function to return basic info about incoming bdf file (ensure no missing
% event codes and ensure event codes map onto events correctly)

function bdfinfo = PLTalkers_pullbdfinfo(EEG, behdta,subjectfolder,setupfolder,subID,jpmcfg)

%{
b=1;
 if isequal(subID,'TCD_sub020') 
     EEG.event(find(isnan([EEG.event(:).duration])))=[];
 end

% channel info (1-32 scalp; 33-40 EX1-8; 43 = photodiode)
% code 11-22 - block start (only code 11 for sub001-002)
% 71 - fixcode (sub001-003 = 21)
% 72 - titlecode (sub001-003 = 22)
% 73 - blankscreen (sub001-003 = 23)
% 101 - video onset (A)
% 102 - video onset (V) 
% 103 - video onset (AVc)
% 104 - video onset (AVi)
% 41 - video end
% 30 - question onset A (Movement)
% 31 - question onset B (Sound)
% 32 - question onset C (Match)
% 255 - response (right arrow: 3)
% 235 - response (down arrow: 2)
% ? - response ( )
% mystery codes - 89, 90, 100, 108, 114, 139, 185, 235, 247, 251
% 101: 51
% 102: 49
% 103: 53
% 104: 32

vidonsettargets= [51    49    53    32];
vidonsetcodetargets= [101 102 103 104];
load([setupfolder 'targetvidonsetlist']);
l2=struct2table(targetvidonsetlist);
l2=l2.edftype;

% Remove unused channels 
disp(['Removing unused channels...']);
        bdfinfo.rawmicrophone=EEG.data(44,:);
        bdfinfo.rawphotodiode=EEG.data(43,:);
        EEG = pop_select( EEG, 'nochannel',{'EXG6','EXG7','EXG8','GSR1','GSR2','Resp','Plet','Temp'});
        EEG = eeg_checkset( EEG );

% Filter EEG (Not ERGs)
 disp(['Filtering EEG...']);
       % EEG = pop_eegfiltnew(EEG, 'locutoff',jpmcfg.filtlo,'hicutoff',jpmcfg.filthi);
        % [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 1,'gui','off');
        EEG  = pop_basicfilter( EEG,  1:37 , 'Boundary', 'boundary', 'Cutoff', [ 0.1 30], 'Design',...
        'butter', 'Filter', 'bandpass', 'Order', 2 ); 
        EEG = eeg_checkset( EEG );

% % Resample EEG
 disp(['Resampling EEG...']);
        EEG = pop_resample( EEG, jpmcfg.resamp);
        EEG = eeg_checkset( EEG );

% Remove events prior to code 11 (Block 1 start)
        bdfinfo.rawevents=EEG.event;
        for i=1:size(bdfinfo.rawevents,2)
        if  isempty(bdfinfo.rawevents(i).edftype)==1
             bdfinfo.rawevents(i).edftype=str2num(bdfinfo.rawevents(i).type);
        end
        end
        events2find = vertcat(bdfinfo.rawevents.edftype);
        EEG = pop_editeventvals(EEG,'delete',1:(find(events2find==11)-1));
        EEG = eeg_checkset( EEG );
        clearvars events2find


% Add channel locations
EEG=pop_chanedit(EEG, 'load',{[setupfolder 'chan_loc_37_momsen.sph.txt'],'filetype','sph'});
        EEG = eeg_checkset( EEG );
%}
       

b=1;
 if isequal(subID,'TCD_sub020') 
     EEG.event(find(isnan([EEG.event(:).duration])))=[];
 end

  if isequal(subID,'TCD_sub001') 
behdtasave=behdta;
  end

% channel info (1-32 scalp; 33-40 EX1-8; 43 = photodiode)
% code 11-22 - block start (only code 11 for sub001-002)
% 71 - fixcode (sub001-003 = 21)
% 72 - titlecode (sub001-003 = 22)
% 73 - blankscreen (sub001-003 = 23)
% 101 - video onset (A)
% 102 - video onset (V) 
% 103 - video onset (AVc)
% 104 - video onset (AVi)
% 41 - video end
% 30 - question onset A (Movement)
% 31 - question onset B (Sound)
% 32 - question onset C (Match)
% 255 - response (right arrow: 3)
% 235 - response (down arrow: 2)
% ? - response ( )
% mystery codes - 89, 90, 100, 108, 114, 139, 185, 235, 247, 251
% 101: 51
% 102: 49
% 103: 53
% 104: 32

vidonsettargets= [51    49    53    32];
vidonsetcodetargets= [101 102 103 104];
load([setupfolder 'targetvidonsetlist']);
l2=struct2table(targetvidonsetlist);
l2=l2.edftype;

% Remove unused channels 
disp(['Removing unused channels...']);
        bdfinfo.rawmicrophone=EEG.data(44,:);
        bdfinfo.rawphotodiode=EEG.data(43,:);
        EEG = pop_select( EEG, 'nochannel',{'EXG6','EXG7','EXG8','GSR1','GSR2','Resp','Plet','Temp'}); % 'T7','T8'
        EEG = eeg_checkset( EEG );

% Filter EEG (Not ERGs)
 disp(['Filtering EEG...']);
       % EEG = pop_eegfiltnew(EEG, 'locutoff',jpmcfg.filtlo,'hicutoff',jpmcfg.filthi);
        % [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 1,'gui','off');
        EEG  = pop_basicfilter( EEG,  1:37 , 'Boundary', 'boundary', 'Cutoff', [ 0.1 30], 'Design',...
        'butter', 'Filter', 'bandpass', 'Order', 2 ); 
        EEG = eeg_checkset( EEG );

% % Resample EEG
 disp(['Resampling EEG...']);
        EEG = pop_resample( EEG, jpmcfg.resamp);
        EEG = eeg_checkset( EEG );




% Remove events prior to code 11 (Block 1 start)
        bdfinfo.rawevents=EEG.event;
        for i=1:size(bdfinfo.rawevents,2)
        if  isempty(bdfinfo.rawevents(i).edftype)==1
             bdfinfo.rawevents(i).edftype=str2num(bdfinfo.rawevents(i).type);
        end
        end
        events2find = vertcat(bdfinfo.rawevents.edftype);
        EEG = pop_editeventvals(EEG,'delete',1:(find(events2find==11)-1));
        EEG = eeg_checkset( EEG );
        clearvars events2find

     % Subject-specific fix 
     if isequal(subID,'TCD_sub001')
         EEG = pop_editeventvals(EEG,'delete',696);
         EEG=eeg_checkset(EEG,'eventconsistency');
         EEG = eeg_checkset( EEG );
     end

% Add channel locations
EEG=pop_chanedit(EEG, 'load',{[setupfolder 'chan_loc_37_momsen.sph.txt'],'filetype','sph'});
        EEG = eeg_checkset( EEG );

% Remove bad chans
        EEG = pop_select( EEG, 'nochannel',{'T7','T8'}); % 
        EEG = eeg_checkset( EEG );

% fill edftype column
        bdfinfo.rawevents=EEG.event;
        for i=1:size(bdfinfo.rawevents,2)
            if  isempty(bdfinfo.rawevents(i).edftype)==1
                bdfinfo.rawevents(i).edftype=str2num(bdfinfo.rawevents(i).type);
            end
        end
        % make copy with vid onsets only

        bdfinfo.rawevents_vidonset=bdfinfo.rawevents;
        for i=1:size(bdfinfo.rawevents_vidonset,2)
            if  sum(bdfinfo.rawevents_vidonset(i).edftype==vidonsetcodetargets)==0
                killer(i)=1;
            else
                killer(i)=0;
            end
        end
        bdfinfo.rawevents_vidonset( find(killer==1))=[];


        % find latencies of each eventcode type (in eegevents)
        events2find = unique(vertcat(bdfinfo.rawevents.edftype));
        events2findnames = num2cell(events2find);
        clearvars trlfind eegeventtimes
        for i=1:length(events2find)
            for t=1:size(bdfinfo.rawevents,2)
                trlfind(t)=isequal(bdfinfo.rawevents(t).edftype, events2find(i));
            end
            typefind=find(double(trlfind)==1)';
            for t=1:length(typefind)
                eegeventtimes.(['code_' num2str(events2findnames{i})])(t)=bdfinfo.rawevents(typefind(t)).latency/EEG.srate;
            end
            clearvars typefind trlfind

        end
        bdfinfo.raweventtimes=eegeventtimes;
        clearvars events2find events2findnames eegeventtimes
        bdfinfo.runtime_mins=max((EEG.times/1000)/60);  % EEG.times (in ms)
        disp(['Total EEG run time: ' num2str(bdfinfo.runtime_mins) ' mins']);



        % how many of each code?
        events2find=fieldnames(bdfinfo.raweventtimes);
        for i=1:length(events2find)
            holder(i)=length(bdfinfo.raweventtimes.(events2find{i}));
        end
        events2find(:,2)=num2cell(holder)';
        bdfinfo.toteventcount=events2find;
        clearvars holder  events2find
        % how many video onset eventcodes?
   
        events2find={'code_101','code_102','code_103','code_104'};
        for i=1:length(events2find)
            holder(i)=length(bdfinfo.raweventtimes.(events2find{i}));
        end
        %         if sum(holder)~=185
        %         disp(['WARNING ' num2str(sum(holder)) ' Video onset codes found']);
        %         pause;
        %         else
        if sum(holder ~= vidonsettargets)>0
            disp(['WARNING ' num2str(sum(holder)) ' Video onset codes found']);
            % pause;
            l1=struct2table(bdfinfo.rawevents_vidonset);
            l1=l1.edftype;
            kk=0;

            % l1==l2(1:183)
            if isequal(subID,'TCD_sub001')
                for ii=1:length([bdfinfo.rawevents_vidonset(:).urevent])
                sub1find(ii)=sum(bdfinfo.rawevents_vidonset(ii).urevent==[behdtasave.bdfinfo.rawevents_vidonset(:).urevent]);
                end
                %bdfinfo.rawevents_vidonset(find(sub1find~=1))=[]; 
                    badonsetcodes=find(sub1find~=1);
            else
                clearvars badcodeID badonsetcodes
                while length(l1)~=length(l2)
                    kk=kk+1;
                    % l1 = current vid onset order; l2 = desired vid onset order
                    for k=1:length(l2)
                        badcodeID(k)=l1(k)==l2(k);
                    end
                    badonsetcodes(kk)=min(find(badcodeID==0));
                    l1(min(find(badcodeID==0)))=[];
                end
            end
        else
            disp([num2str(sum(holder)) ' Video onset codes found']);
            badonsetcodes=0;
        end
        clearvars holder
        events2find={'code_41'}; %vid offset
        for i=1:length(events2find)
            holder(i)=length(bdfinfo.raweventtimes.(events2find{i}));
        end
        disp([num2str(sum(holder)) ' Video offset codes found']);



        % plot event timeline
        %{
        codes2find=[101;102;103;104];
        %codes2find=[41];
        blocks2find=[11:1:20];
        eventplot=zeros(1,length(EEG.times));
            for i=1:length(bdfinfo.rawevents)
                if sum(bdfinfo.rawevents(i).edftype==blocks2find)>0
                   eventplot(1,round(bdfinfo.rawevents(i).latency))=10;
                end
                if sum(bdfinfo.rawevents(i).edftype==codes2find)>0
                   eventplot(1,round(bdfinfo.rawevents(i).latency))=5;
                end
            end
          blockstarts=find(eventplot==10);
          vidstarts=find(eventplot==5);
          for i=1:length(blockstarts)
              if i<length(blockstarts)
                vidcounts(i)= sum(blockstarts(i+1)>vidstarts & vidstarts>blockstarts(i));
              else
                vidcounts(i)= sum( vidstarts>blockstarts(i));
              end
          end
            h=figure, set(h,'Position',[40 200 560 420])
            plot(EEG.times/1000,eventplot)
            xlabel('Time (s)')
            ylabel('Blocks and video onsets')
            dim = [.2 .5 .3 .3];
            str =['Vid onsets per block ' num2str(vidcounts) ] ;
            %str =['Vid offsets per block ' num2str(vidcounts) ] ;
            annotation('textbox',dim,'String',str,'FitBoxToText','on');
            clearvars vids2find blocks2find eventplot blockstarts vidstarts vidcounts
        %}

        % make master trial data table (for behavioral responses)
        %{
        disp(['Compiling behavioral data...']);
        bdfinfo.behdata=behdta.bdfinfo.behdata;
        bdfinfo.behdata(:,9:76)=[];
        bdfinfo.behdata(:,11:18)=[];
        bdfinfo.behdata(:,12:16)=[];
        bdfinfo.behdata(:,1)=[];
        for i=1:size(bdfinfo.behdata,1)
            vidpath=bdfinfo.behdata.VideoPath{i};
            bdfinfo.behdata.VideoPath{i}=bdfinfo.behdata.VideoPath{i}((strfind(vidpath,'All\')+4):(strfind(vidpath,'.mp4')-1));
            clearvars vidpath
        end
        %}

        % Clear superfluous codes from EEGLAB
        disp(['Removing non-target event codes...']);
        events2keep=([11:22 101 102 103 104 41]);
        clearvars eventkill
        for i=1:length(EEG.event)
            if ismember(bdfinfo.rawevents(i).edftype,events2keep)
                eventkill(i)=0;
            else
                eventkill(i)=1;
            end
        end
        clearvars events2keep
        EEG = pop_editeventvals(EEG,'delete',find(eventkill==1));
        %[ALLEEG EEG] = eeg_store(ALLEEG, EEG, CURRENTSET);
        EEG = eeg_checkset( EEG );
        % EEG = pop_eraseventcodes( EEG, '>255' );

        % Drop erroneous onset codes
        if badonsetcodes(1)~=0
            clearvars killer
            eventhold= struct2table(EEG.event);
            eventhold=eventhold.latency;
            for k=1:length(badonsetcodes)
                killer(k)=find(eventhold==bdfinfo.rawevents_vidonset(badonsetcodes(k)).latency);
            end
            bdfinfo.droppedcodes=EEG.event(killer);
            EEG.event(killer)=[];
        else
            bdfinfo.droppedcodes='none';
        end

        % Insert item-specific codes for all video onsets
        bdfinfo.behdata=behdta.bdfinfo.behdata;
        EEGeventhold =EEG.event;
        EEGureventhold =EEG.urevent;
        targetcodes=([101 102 103 104]);
        currtrial=0;
        for i=1:length(EEGeventhold)
            if find(ismember(targetcodes,str2num(EEGeventhold(i).type)))>0
                currtrial=currtrial+1;
                currblock=bdfinfo.behdata.Block(currtrial);
                if length(num2str(bdfinfo.behdata.Trialcode(currtrial)))<2
                    newcode=[ EEGeventhold(i).type '0' num2str(bdfinfo.behdata.Trialcode(currtrial))];
                else
                    newcode=[ EEGeventhold(i).type num2str(bdfinfo.behdata.Trialcode(currtrial))];
                end
                if currblock~=1 && currblock~=2 && currblock~=4 && currblock~=5 && currblock~=7 && currblock~=8 && currblock~=10 && currblock~=11
                    newcode=['2' newcode];
                else
                    newcode=['1' newcode];
                end
                EEGeventhold(length(EEGeventhold)+1).type= newcode;
                EEGeventhold(length(EEGeventhold)).edftype=str2num(EEGeventhold(length(EEGeventhold)).type);
                EEGeventhold(length(EEGeventhold)).latency=EEGeventhold(i).latency+1;
                EEGureventhold(length(EEGureventhold)+1).type=newcode;
                EEGureventhold(length(EEGureventhold)).edftype=str2num(EEGeventhold(length(EEGeventhold)).type);
                EEGureventhold(length(EEGureventhold)).latency=EEGeventhold(i).latency+1;
                EEGeventhold(length(EEGeventhold)).urevent=length(EEGureventhold);
            end
        end
        EEG.event=EEGeventhold ;
        EEG.urevent=EEGureventhold ;
        EEG=eeg_checkset(EEG,'eventconsistency');

        %newcode = 6 digits
        % 1st = Gesture = 1; Dance = 2
        % @nd-4th = condition code , e.g., 101
        % 5th-6th = Stimulus ID (01 to 40ish)


        if isequal(jpmcfg.runICA,'yes')

            % Run ICA
            disp(['Starting ICA...']);
            tic;
            EEG = pop_runica(EEG, 'icatype', 'runica', 'extended',1,'interrupt','on');
            EEG = eeg_checkset( EEG );

            % Save .set
            disp(['Saving ICA.set...']);
            EEG = pop_saveset( EEG, 'filename',['TCD_ICAcont_yale_' subID '.set'],'filepath',subjectfolder);
            EEG = eeg_checkset( EEG );
        end


   %{
        % Create Eventlist
        disp(['Creating Eventlist...']);
        EEG  = pop_creabasiceventlist( EEG , 'AlphanumericCleaning', 'on',...
            'BoundaryNumeric', { -99 }, 'BoundaryString',{ 'boundary' } );
        EEG = eeg_checkset( EEG );

   % Epoch data Eventlist
        disp(['Epoching data...']);
        EEG = pop_epoch( EEG, {  '101'  '102'  '103'  '104'  }, [-1  20], 'newname', [subID '_epochs'], 'epochinfo', 'yes');
        EEG = eeg_checkset( EEG );

        % Remove Erg chans and save
        disp(['Removing Erg channels...']);
        bdfinfo.microphone=EEG.data(37,:,:);
        bdfinfo.photodiode=EEG.data(36,:,:);
        EEG = pop_select( EEG, 'nochannel',{'E36','E37'});
        EEG = eeg_checkset( EEG );

   %}