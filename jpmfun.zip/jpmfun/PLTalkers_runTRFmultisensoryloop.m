function     [TRF_master_all] = PLTalkers_runTRFmultisensoryloop(readme,trfhld)


clearvars trflooper
subidx_trinity=readme.subidx(find(contains(cell2table(readme.subidx(:,2)).Var1,'pilot' )),:);
Atrls=subidx_trinity(ismember(cell2table(subidx_trinity(:,4)).Var1,'A'),:);
Vtrls=subidx_trinity(ismember(cell2table(subidx_trinity(:,4)).Var1,'V'),:);
AVCtrls=subidx_trinity(ismember(cell2table(subidx_trinity(:,4)).Var1,'AVC'),:);
AVItrls=subidx_trinity(ismember(cell2table(subidx_trinity(:,4)).Var1,'AVI'),:);
% row 5 = trial ID for each stim (all from that clip)
% row 7 = artifact flag
% row 8 = trial order from EEG recording
Atrls=sortrows(Atrls,5);
Vtrls=sortrows(Vtrls,5);
AVCtrls=sortrows(AVCtrls,5);
AVItrls=sortrows(AVItrls,5);
stimswithflags.Atrls=find(ismember(Atrls(:,7),cellstr('1'))==1);
stimswithflags.Vtrls=find(ismember(Vtrls(:,7),cellstr('1'))==1);
stimswithflags.AVCtrls=find(ismember(AVCtrls(:,7),cellstr('1'))==1);
stimswithflags.AVItrls=find(ismember(AVItrls(:,7),cellstr('1'))==1);
stimswithflags.A_V_AVC=unique(vertcat(stimswithflags.Atrls,stimswithflags.Vtrls,stimswithflags.AVCtrls));
stimswithflags.A_V_AVC_AVI=unique(vertcat(stimswithflags.Atrls,stimswithflags.Vtrls,stimswithflags.AVCtrls,stimswithflags.AVItrls));

trflooper.trinity.subidx_trinity=subidx_trinity;
trflooper.trinity.Atrls=Atrls;
trflooper.trinity.Vtrls=Vtrls;
trflooper.trinity.AVCtrls=AVCtrls;
trflooper.trinity.AVItrls=AVItrls;
trflooper.trinity.stimswithflags=stimswithflags;
clearvars subidx_trinity  Atrls Vtrls AVCtrls AVItrls stimswithflags

% fill good trial info into cells
holder=readme.trfnames_trinity;
holder(1)=[];
stimnames.audio=holder(contains(holder,'env'));
stimnames.biomot=holder(~contains(holder,'env'));
audiostims=stimnames.audio;
biomotstims=stimnames.biomot;
condnames=fieldnames(trflooper.trinity);
%condnames=fieldnames(trflooper.(loopernames{d}));
condnames(length(condnames))=[];
condnames(1)=[];
loopernames={'trinity'};
d=1;
stimnameidx=trfhld.trinity.audio.(audiostims{1})(:,2);
stimnameidx(:,2)=trfhld.trinity.bmot.globmot(:,2);

condnames(1)={'Atrls'  };
condnames(2)={'Vtrls'  };
condnames(3)={'AVCtrls'  };
condnames(4)={'AVItrls'  };

 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Loop to drop trials with flags across all conditions
clearvars ALLtrialinfo rtrain strain ALLstrain ALLrtrain stest rtest loopsize rtrain
loopsize=size(trflooper.(loopernames{d}).(condnames{1}),1);
counter=0;
for t=1:loopsize
    %counter=0;
    if ismember(t,trflooper.(loopernames{d}).stimswithflags.A_V_AVC_AVI)==1
        continue
    end
    counter=counter+1;
    for c=1:length(condnames)
        stim_cond=   trflooper.(loopernames{d}).(condnames{c}){t,2}{1};
        stimfind = find(ismember(stimnameidx(:,1),stim_cond));
        eegtrl=str2num(trflooper.(loopernames{d}).(condnames{c}){t,8});
        rtrain.(condnames{c}){counter,1}=trfhld.trinity.eeg{stimfind,1}; % NEED TO CARRY CODES TO IDENTIFY WHICH OVERALL TRIAL CORRESPONDS TO THIS STIMULUS find(ismember(trfhld.trinity.eegtrial,trflooper.(loopernames{d}).(condnames{c}){t,8}))
        ALLtrialinfo.(condnames{c}).stim{counter,1}= strrep(trflooper.(loopernames{d}).(condnames{c}){t,2},'pilot_','stim');
        ALLtrialinfo.(condnames{c}).stim{counter,2}= stim_cond;
        ALLtrialinfo.(condnames{c}).stim{counter,3}= eegtrl;
        ALLtrialinfo.(condnames{c}).stim{counter,4}= stimfind;
        for st=1:length(audiostims)
            strain.(condnames{c}).(audiostims{st}){counter,1}=trfhld.trinity.audio.(audiostims{st}){stimfind,1};
        end
        for st=1:length(biomotstims)
            strain.(condnames{c}).(biomotstims{st}){counter,1}=trfhld.trinity.biomot.(biomotstims{st}){stimfind,1};
        end
    end
end





% Clip to shortest stim above jacob ending here
fs=readme.fs;
Dir=readme.Dir;
tmin=readme.tmin;
tmax=readme.tmax;
lambda=readme.lambda;
zeropad=readme.zeropad;

% Loop to make all stim resp same sample length
clearvars tottrlsize
tottrlsize=size(strain.(condnames{c}).(audiostims{1}),1);
%{
for stt=1:length(audiostims) % stim type
    %for c=1:length(condnames)
        for t=1:tottrlsize  %size(trflooper.(loopernames{d}).(condnames{c}),1) % t = num trials in multitrain loop
 [~,minidx]= min([size(strain.(condnames{1}).(audiostims{stt}){t},1) size(rtrain.(condnames{1}){t},1) size(rtrain.(condnames{2}){t},1) size(rtrain.(condnames{3}){t},1) size(rtrain.(condnames{4}){t},1) ]);
if minidx==1
    for c=1:length(condnames)
        for ii=1:abs(size(strain.(condnames{1}).(audiostims{stt}){t},1)-size(rtrain.(condnames{c}){t},1))
                rtrain.(condnames{c}){t}(end,:)=[];
        end
    end
end

if minidx==2
        for ii=1:abs(size(strain.(condnames{1}).(audiostims{stt}){t},1)-size(rtrain.(condnames{1}){t},1))
                strain.(condnames{1}).(audiostims{stt}){t}(end,:)=[];
        end
    for c=1:length(condnames)
        if c==1
            continue
        end
        for ii=1:abs(size(rtrain.(condnames{1}){t},1)-size(rtrain.(condnames{c}){t},1))
                rtrain.(condnames{c}){t}(end,:)=[];
        end
    end
end

if minidx==3
        for ii=1:abs(size(strain.(condnames{1}).(audiostims{stt}){t},1)-size(rtrain.(condnames{2}){t},1))
                strain.(condnames{1}).(audiostims{stt}){t}(end,:)=[];
        end
    for c=1:length(condnames)
        if c==2
            continue
        end
        for ii=1:abs(size(rtrain.(condnames{2}){t},1)-size(rtrain.(condnames{c}){t},1))
                rtrain.(condnames{c}){t}(end,:)=[];
        end
    end

end
if minidx==4
        for ii=1:abs(size(strain.(condnames{1}).(audiostims{stt}){t},1)-size(rtrain.(condnames{3}){t},1))
                strain.(condnames{1}).(audiostims{stt}){t}(end,:)=[];
        end
    for c=1:length(condnames)
        if c==3
            continue
        end
        for ii=1:abs(size(rtrain.(condnames{3}){t},1)-size(rtrain.(condnames{c}){t},1))
                rtrain.(condnames{c}){t}(end,:)=[];
        end
    end
end
if minidx==5
        for ii=1:abs(size(strain.(condnames{1}).(audiostims{stt}){t},1)-size(rtrain.(condnames{4}){t},1))
                strain.(condnames{1}).(audiostims{stt}){t}(end,:)=[];
        end
    for c=1:length(condnames)
        if c==4
            continue
        end
        for ii=1:abs(size(rtrain.(condnames{4}){t},1)-size(rtrain.(condnames{c}){t},1))
                rtrain.(condnames{c}){t}(end,:)=[];
        end
    end

end

        end
end
%}


st=1;

ALLstrain=strain;
ALLrtrain=rtrain;


clearvars strain rtrain stest rtest
clearvars strain_Atrls strain_Vtrls strain_AVCtrls strain_AVItrls 
clearvars rtrain_Atrls rtrain_Vtrls rtrain_AVCtrls rtrain_AVItrls 
clearvars stimlist_Atrls stimlist_Vtrls stimlist_AVCtrls stimlist_AVItrls
clearvars rtest_Atrls rtest_Vtrls rtest_AVCtrls rtest_AVItrls 
clearvars stest_Atrls stest_Vtrls stest_AVCtrls stest_AVItrls 

for c=1:length(condnames)
    %stest.(condnames{c})=ALLstrain.(condnames{c}).(audiostims{st}){t,1};%%%%
    strain.(condnames{c})=ALLstrain.(condnames{c}).(audiostims{st});%%%%%%%
    %strain.(condnames{c})(t)=[];
    % if isequal(condnames{c},'AVCtrls')
    %rtest.(condnames{c})=ALLrtrain.(condnames{c}){t,1};
    % end
    rtrain.(condnames{c})=ALLrtrain.(condnames{c});
    %rtrain.(condnames{c})(t)=[];
end


stimlist_Atrls=ALLtrialinfo.(condnames{1}).stim(:,1);
stimlist_Vtrls=ALLtrialinfo.(condnames{2}).stim(:,1);
stimlist_AVCtrls=ALLtrialinfo.(condnames{3}).stim(:,1);
stimlist_AVItrls=ALLtrialinfo.(condnames{4}).stim(:,1);



for t=1:tottrlsize % t = num trials in multitrain loop
        strain_Atrls{t}=strain.(condnames{1});
        strain_Vtrls{t}=strain.(condnames{2});
        strain_AVCtrls{t}=strain.(condnames{3});
        strain_AVItrls{t}=strain.(condnames{4});
            rtrain_Atrls{t}=rtrain.(condnames{1});
            rtrain_Vtrls{t}=rtrain.(condnames{2});
            rtrain_AVCtrls{t}=rtrain.(condnames{3});
            rtrain_AVItrls{t}=rtrain.(condnames{4});
        
        stest_Atrls{t}=strain_Atrls{t}{t};
        stest_Vtrls{t}=strain_Vtrls{t}{t};
        stest_AVCtrls{t}=strain_AVCtrls{t}{t};
        stest_AVItrls{t}=strain_AVItrls{t}{t};
            
        rtest_Atrls{t}=rtrain_Atrls{t}{t};
        rtest_Vtrls{t}=rtrain_Vtrls{t}{t};
        rtest_AVCtrls{t}=rtrain_AVCtrls{t}{t};
        rtest_AVItrls{t}=rtrain_AVItrls{t}{t};
        
        strain_Atrls{t}(t)=[];
        strain_Vtrls{t}(t)=[];
        strain_AVCtrls{t}(t)=[];
        strain_AVItrls{t}(t)=[];
        
        rtrain_Atrls{t}(t)=[];
        rtrain_Vtrls{t}(t)=[];
        rtrain_AVCtrls{t}(t)=[];
        rtrain_AVItrls{t}(t)=[];
end



    cvback = mTRFcrossval(strain_Atrls{t},rtrain_Atrls{t},fs,-1,tmin,tmax,lambda,'zeropad',zeropad,'fast',1);
    cvfwd = mTRFcrossval(strain_Atrls{t},rtrain_Atrls{t},fs,1,tmin,tmax,lambda,'zeropad',zeropad,'fast',1);

%%%%%%%%%%%%%%%%% TRF computations below %%%%%%%%%%'
% Run loop - Atrls
parfor t=1:tottrlsize 
    cv{t} = mTRFcrossval(strain_Atrls{t},rtrain_Atrls{t},fs,Dir,tmin,tmax,lambda,'zeropad',zeropad,'fast',1);
    if Dir==-1
        [rmax{t},idx{t}] = max(mean(cv{t}.r,1));
        model{t} = mTRFtrain(strain_Atrls{t},rtrain_Atrls{t},fs,Dir,tmin,tmax,lambda(idx{t}),'zeropad',zeropad);
        [pred{t},test{t}]=mTRFpredict(stest_Atrls{t},rtest_Atrls{t},model{t},'zeropad',zeropad);
        forwardmodel{t} = mTRFtransform(model{t},rtrain_Atrls{t});
    else
        [rmax{t},idx{t}] = max(mean(mean(cv{t}.r,3),1));
        forwardmodel{t} = mTRFtrain(strain_Atrls{t},rtrain_Atrls{t},fs,Dir,tmin,tmax,lambda(idx{t}),'zeropad',zeropad);
        [pred{t},test{t}]=mTRFpredict(stest_Atrls{t},rtest_Atrls{t},forwardmodel{t},'zeropad',zeropad);
        model{t} = [];
    end
end
TRF_master.(audiostims{1}).(condnames{1}).cv=cv;
TRF_master.(audiostims{1}).(condnames{1}).rmax=rmax;
TRF_master.(audiostims{1}).(condnames{1}).idx=idx;
TRF_master.(audiostims{1}).(condnames{1}).model=model;
TRF_master.(audiostims{1}).(condnames{1}).pred=pred;
TRF_master.(audiostims{1}).(condnames{1}).test=test;
TRF_master.(audiostims{1}).(condnames{1}).forwardmodel=forwardmodel;
TRF_master.(audiostims{1}).(condnames{1}).stimnames=stimlist_Atrls;
TRF_master.(audiostims{1}).(condnames{1}).rtrain=rtrain_Atrls;
TRF_master.(audiostims{1}).(condnames{1}).rtest=rtest_Atrls;
TRF_master.(audiostims{1}).(condnames{1}).strain=strain_Atrls;
TRF_master.(audiostims{1}).(condnames{1}).stest=stest_Atrls;
%TRF_master.(audiostims{1}).(condnames{1}).natrating=ALLtrialinfo.(condnames{1}).stim{t,2};
TRF_master.(audiostims{1}).(condnames{1}).originalepochnum=ALLtrialinfo.(condnames{1}).stim(:,3);
clearvars model forwardmodel test pred cv rmax idx parameter rndperms cv1
if isequal(readme.runnull,'yes')
    if Dir==-1 
        cv = mTRFcrossval(strain.(condnames{1}),rtrain.(condnames{1}),fs,Dir,tmin,tmax,lambda,'zeropad',zeropad,'fast',1);
        [rmax,idx] = max(mean(cv.r,1));
        rndperms.stats = mTRFpermute(strain.(condnames{1}),rtrain.(condnames{1}),fs,Dir,'permute',tmin,tmax,lambda(idx));
        rndperms.cv=cv;
        rndperms.idx=idx;
        rndperms.rmax=rmax;
    TRF_master.(audiostims{1}).(condnames{1}).rndperms=rndperms;clc;
    clearvars model forwardmodel test pred cv rmax idx parameter rndperms
    end
else
TRF_master.(audiostims{1}).(condnames{1}).rndperms=[];
end

% Run loop - Vtrls
parfor t=1:tottrlsize 
    cv{t} = mTRFcrossval(strain_Vtrls{t},rtrain_Vtrls{t},fs,Dir,tmin,tmax,lambda,'zeropad',zeropad,'fast',1);
    if Dir==-1
        [rmax{t},idx{t}] = max(mean(cv{t}.r,1));
        model{t} = mTRFtrain(strain_Vtrls{t},rtrain_Vtrls{t},fs,Dir,tmin,tmax,lambda(idx{t}),'zeropad',zeropad);
        [pred{t},test{t}]=mTRFpredict(stest_Vtrls{t},rtest_Vtrls{t},model{t},'zeropad',zeropad);
        forwardmodel{t} = mTRFtransform(model{t},rtrain_Vtrls{t});
    else
        [rmax{t},idx{t}] = max(mean(mean(cv{t}.r,1),3));
        forwardmodel{t} = mTRFtrain(strain_Vtrls{t},rtrain_Vtrls{t},fs,Dir,tmin,tmax,lambda(idx{t}),'zeropad',zeropad);
        [pred{t},test{t}]=mTRFpredict(stest_Vtrls{t},rtest_Vtrls{t},forwardmodel{t},'zeropad',zeropad);
        model{t} = [];
    end
end
TRF_master.(audiostims{1}).(condnames{2}).cv=cv;
TRF_master.(audiostims{1}).(condnames{2}).rmax=rmax;
TRF_master.(audiostims{1}).(condnames{2}).idx=idx;
TRF_master.(audiostims{1}).(condnames{2}).model=model;
TRF_master.(audiostims{1}).(condnames{2}).pred=pred;
TRF_master.(audiostims{1}).(condnames{2}).test=test;
TRF_master.(audiostims{1}).(condnames{2}).forwardmodel=forwardmodel;
TRF_master.(audiostims{1}).(condnames{2}).stimnames=stimlist_Vtrls;
TRF_master.(audiostims{1}).(condnames{2}).rtrain=rtrain_Vtrls;
TRF_master.(audiostims{1}).(condnames{2}).rtest=rtest_Vtrls;
TRF_master.(audiostims{1}).(condnames{2}).strain=strain_Vtrls;
TRF_master.(audiostims{1}).(condnames{2}).stest=stest_Vtrls;
%TRF_master.(audiostims{1}).(condnames{1}).natrating=ALLtrialinfo.(condnames{1}).stim{t,2};
TRF_master.(audiostims{1}).(condnames{2}).originalepochnum=ALLtrialinfo.(condnames{2}).stim(:,3);
clearvars model forwardmodel test pred cv rmax idx parameter rndperms cv1
if isequal(readme.runnull,'yes')
if Dir==-1
    cv = mTRFcrossval(strain.(condnames{2}),rtrain.(condnames{2}),fs,Dir,tmin,tmax,lambda,'zeropad',zeropad,'fast',1);
    [rmax,idx] = max(mean(cv.r,1));
    rndperms.stats = mTRFpermute(strain.(condnames{2}),rtrain.(condnames{2}),fs,Dir,'permute',tmin,tmax,lambda(idx));
    rndperms.cv=cv;
    rndperms.idx=idx;
    rndperms.rmax=rmax;
TRF_master.(audiostims{1}).(condnames{2}).rndperms=rndperms;
clearvars model forwardmodel test pred cv rmax idx parameter rndperms
end
else
TRF_master.(audiostims{1}).(condnames{1}).rndperms=[];
end

% Run loop - AVCtrls
parfor t=1:tottrlsize 
    cv{t} = mTRFcrossval(strain_AVCtrls{t},rtrain_AVCtrls{t},fs,Dir,tmin,tmax,lambda,'zeropad',zeropad,'fast',1);
    if Dir==-1
        [rmax{t},idx{t}] = max(mean(cv{t}.r,1));
        model{t} = mTRFtrain(strain_AVCtrls{t},rtrain_AVCtrls{t},fs,Dir,tmin,tmax,lambda(idx{t}),'zeropad',zeropad);
        [pred{t},test{t}]=mTRFpredict(stest_AVCtrls{t},rtest_AVCtrls{t},model{t},'zeropad',zeropad);
        forwardmodel{t} = mTRFtransform(model{t},rtrain_AVCtrls{t});
    else
        [rmax{t},idx{t}] = max(mean(mean(cv{t}.r,1),3));
        forwardmodel{t} = mTRFtrain(strain_AVCtrls{t},rtrain_AVCtrls{t},fs,Dir,tmin,tmax,lambda(idx{t}),'zeropad',zeropad);
        [pred{t},test{t}]=mTRFpredict(stest_AVCtrls{t},rtest_AVCtrls{t},forwardmodel{t},'zeropad',zeropad);
        model{t} = [];
    end
end
TRF_master.(audiostims{1}).(condnames{3}).cv=cv;
TRF_master.(audiostims{1}).(condnames{3}).rmax=rmax;
TRF_master.(audiostims{1}).(condnames{3}).idx=idx;
TRF_master.(audiostims{1}).(condnames{3}).model=model;
TRF_master.(audiostims{1}).(condnames{3}).pred=pred;
TRF_master.(audiostims{1}).(condnames{3}).test=test;
TRF_master.(audiostims{1}).(condnames{3}).forwardmodel=forwardmodel;
TRF_master.(audiostims{1}).(condnames{3}).stimnames=stimlist_AVCtrls;
TRF_master.(audiostims{1}).(condnames{3}).rtrain=rtrain_AVCtrls;
TRF_master.(audiostims{1}).(condnames{3}).rtest=rtest_AVCtrls;
TRF_master.(audiostims{1}).(condnames{3}).strain=strain_AVCtrls;
TRF_master.(audiostims{1}).(condnames{3}).stest=stest_AVCtrls;
%TRF_master.(audiostims{1}).(condnames{1}).natrating=ALLtrialinfo.(condnames{1}).stim{t,2};
TRF_master.(audiostims{1}).(condnames{3}).originalepochnum=ALLtrialinfo.(condnames{3}).stim(:,3);
clearvars model forwardmodel test pred cv rmax idx parameter rndperms cv1
if isequal(readme.runnull,'yes')
if Dir==-1
    cv = mTRFcrossval(strain.(condnames{3}),rtrain.(condnames{3}),fs,Dir,tmin,tmax,lambda,'zeropad',zeropad,'fast',1);
    [rmax,idx] = max(mean(cv.r,1));
    rndperms.stats = mTRFpermute(strain.(condnames{3}),rtrain.(condnames{3}),fs,Dir,'permute',tmin,tmax,lambda(idx));
    rndperms.cv=cv;
    rndperms.idx=idx;
    rndperms.rmax=rmax;
TRF_master.(audiostims{1}).(condnames{3}).rndperms=rndperms;
clearvars model forwardmodel test pred cv rmax idx parameter rndperms
end
else
TRF_master.(audiostims{1}).(condnames{1}).rndperms=[];
end

% Run loop - AVItrls
parfor t=1:tottrlsize 
    cv{t} = mTRFcrossval(strain_AVItrls{t},rtrain_AVItrls{t},fs,Dir,tmin,tmax,lambda,'zeropad',zeropad,'fast',1);
    if Dir==-1
        [rmax{t},idx{t}] = max(mean(cv{t}.r,1));
        model{t} = mTRFtrain(strain_AVItrls{t},rtrain_AVItrls{t},fs,Dir,tmin,tmax,lambda(idx{t}),'zeropad',zeropad);
        [pred{t},test{t}]=mTRFpredict(stest_AVItrls{t},rtest_AVItrls{t},model{t},'zeropad',zeropad);
        forwardmodel{t} = mTRFtransform(model{t},rtrain_AVItrls{t});
    else
        [rmax{t},idx{t}] = max(mean(mean(cv{t}.r,1),3));
        forwardmodel{t} = mTRFtrain(strain_AVItrls{t},rtrain_AVItrls{t},fs,Dir,tmin,tmax,lambda(idx{t}),'zeropad',zeropad);
        [pred{t},test{t}]=mTRFpredict(stest_AVItrls{t},rtest_AVItrls{t},forwardmodel{t},'zeropad',zeropad);
        model{t} = [];
    end
end
TRF_master.(audiostims{1}).(condnames{4}).cv=cv;
TRF_master.(audiostims{1}).(condnames{4}).rmax=rmax;
TRF_master.(audiostims{1}).(condnames{4}).idx=idx;
TRF_master.(audiostims{1}).(condnames{4}).model=model;
TRF_master.(audiostims{1}).(condnames{4}).pred=pred;
TRF_master.(audiostims{1}).(condnames{4}).test=test;
TRF_master.(audiostims{1}).(condnames{4}).forwardmodel=forwardmodel;
TRF_master.(audiostims{1}).(condnames{4}).stimnames=stimlist_AVItrls;
TRF_master.(audiostims{1}).(condnames{4}).rtrain=rtrain_AVItrls;
TRF_master.(audiostims{1}).(condnames{4}).rtest=rtest_AVItrls;
TRF_master.(audiostims{1}).(condnames{4}).strain=strain_AVItrls;
TRF_master.(audiostims{1}).(condnames{4}).stest=stest_AVItrls;
%TRF_master.(audiostims{1}).(condnames{1}).natrating=ALLtrialinfo.(condnames{1}).stim{t,2};
TRF_master.(audiostims{1}).(condnames{4}).originalepochnum=ALLtrialinfo.(condnames{4}).stim(:,3);
clearvars model forwardmodel test pred cv rmax idx parameter rndperms cv1
if isequal(readme.runnull,'yes')
if Dir==-1
    cv = mTRFcrossval(strain.(condnames{4}),rtrain.(condnames{4}),fs,Dir,tmin,tmax,lambda,'zeropad',zeropad,'fast',1);
    [rmax,idx] = max(mean(cv.r,1));
    rndperms.stats = mTRFpermute(strain.(condnames{4}),rtrain.(condnames{4}),fs,Dir,'permute',tmin,tmax,lambda(idx));
    rndperms.cv=cv;
    rndperms.idx=idx;
    rndperms.rmax=rmax;
TRF_master.(audiostims{1}).(condnames{4}).rndperms=rndperms;
clearvars model forwardmodel test pred cv rmax idx parameter rndperms
end
else
TRF_master.(audiostims{1}).(condnames{1}).rndperms=[];
end




TRF_master_all.(loopernames{d})=TRF_master;
clearvars TRF_master

