
% [gtspeechenv] = PLTalkers_speechenv(audio,fs,setupfolder,pynames)


% Speech Envelope Extraction Using a Gammatone Filterbank
% This script processes an audio file to extract its broadband envelope.



close all
clearvars
clc
homefolder='/Users/jpohaku/Documents/Yale/Research/Yale_PLtalkersJCON/';

dsh=homefolder(end);
cd(homefolder)
addpath(genpath(homefolder))
format long g

subjectfolder=[homefolder 'TCD_studydata' dsh];
setupfolder=[homefolder 'setupfiles' dsh];
outputfolder=[homefolder 'TRFoutput' dsh];
Afolder=[homefolder 'audiofiles' dsh];

% Parallel processing setup - open a parallel pool if not already open
if isempty(gcp('nocreate'))
   % parpool(7);  % Opens a parallel pool with default settings
    parpool('Threads', 14)
end

 clearvars stiminfomaster
load([setupfolder 'psyPyaudiotrinity.mat']);
load([setupfolder 'trinitystims.mat']);
load([setupfolder 'stims_globmot.mat']);
stiminfomaster.trinitytimeinfo = readtable([setupfolder 'shortlist_AVstimmaster.xlsx'],'Sheet', 'trinity_timeinfo');
stiminfomaster.trinity = readtable([setupfolder 'shortlist_AVstimmaster.xlsx'],'Sheet', 'trinity_allstims');
stiminfomaster.aist = readtable([setupfolder 'shortlist_AVstimmaster.xlsx'],'Sheet', 'aist_allstims');
stiminfomaster.trinitystims =trinitystims;
stiminfomaster.trinitystims_globmot =trinity_globmot;
fnames_trinity=fieldnames(trinitystims);
basenames_trinity=strrep(fnames_trinity,'wav_','');
basenames_trinity=strrep(basenames_trinity,'Recording','');
gmotnames=fieldnames(stiminfomaster.trinitystims_globmot);
pynames=fieldnames(psyPyaudiotrinity);
clearvars trfhld corefind corestims
trinitycounter=0;



for py=36:length(pynames)

 
 % [gtspeechenv] = PLTalkers_speechenv(psyPyaudiotrinity.(pynames{py}).wav,psyPyaudiotrinity.(pynames{py}).wavSR,setupfolder,pynames{py});


audio=psyPyaudiotrinity.(pynames{py}).wav;
fs=psyPyaudiotrinity.(pynames{py}).wavSR;

audio = mean(audio, 2); % Convert to mono if stereo


% Define frequency bands (logarithmically spaced)
num_bands = 128;
low_freq = 100;
high_freq = 6500;
center_freqs = logspace(log10(low_freq), log10(high_freq), num_bands);

% Create a DataQueue for progress updates
D = parallel.pool.DataQueue;

filtered_signals = PLT_gammatone_filter(audio, fs, center_freqs,D,num_bands);

% % Apply optimized gammatone filterbank
% filtered_signals = fast_gammatone_filterbank(audio, fs, center_freqs);
% 
% % Step 3: Apply Gammatone Filterbank
% % Requires the 'GammaTone Filterbank Toolkit' (Auditory Toolbox)
% filtered_signals = cell(length(audio), num_bands);
% 
% parfor i = 1:num_bands
%     % Create gammatone filter for current center frequency
%     filtered_signals{i} = PLT_gammatone_filter(audio, fs, cf(i));
% end
% 
% 
% filtered_signals=horzcat([filtered_signals{:,1}]);

% Step 4: Compute the Envelope Using the Hilbert Transform
narrowband_envelopes = abs(hilbert(filtered_signals));

% Step 5: Compute the Broadband Envelope
broadband_envelope = mean(narrowband_envelopes, 2);

% % % Step 6: Plot the Result
% t = (1:length(audio)) / fs; % Time axis
% figure;
% for pn=1:num_bands
% subplot(num_bands,1,pn)
% plot(t, narrowband_envelopes(:,pn), 'k', 'LineWidth', 1.5);
% xlabel('Time (s)');
% ylabel('Amplitude');
% title(['Broadband Speech Envelope' num2str(center_freqs(pn))]);
% grid on;
% end


gtspeechenv=[];
gtspeechenv.fs = fs; % Number of frequency bands
gtspeechenv.center_freqs =center_freqs;
gtspeechenv.num_bands = num_bands; % Number of frequency bands
gtspeechenv.low_freq = low_freq;  % Lower cutoff frequency (Hz)
gtspeechenv.high_freq = high_freq; % Upper cutoff frequency (Hz)
gtspeechenv.filtered_signals=filtered_signals;
% Step 4: Compute the Envelope Using the Hilbert Transform
gtspeechenv.narrowband_envelopes = narrowband_envelopes;
% Step 5: Compute the Broadband Envelope
gtspeechenv.broadband_envelope = broadband_envelope;
% Optional: Save the Envelope for Further Analysis
save([Afolder 'gtspeechenv_' pynames{py} '.mat'], 'gtspeechenv', '-v7.3');

end



